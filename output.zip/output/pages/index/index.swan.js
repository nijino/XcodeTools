"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view s-for=\"item in items\" class=\"single-item\" on-bindtap=\"eventHappen('tap', $event, 'oneItemClick', '')\" on-bindtouchstart=\"eventHappen('touchstart', $event, 'oneItemTouchStart', '')\" on-bindtouchmove=\"eventHappen('touchmove', $event, 'oneItemTouchmove', '')\" on-bindtouchcancel=\"eventHappen('touchcancel', $event, 'oneItemTouchcancel', '')\" on-bindtouchend=\"eventHappen('touchend', $event, 'oneItemTouchEnd', '')\">\n    <image src=\"{{item.imgsrc}}\" class=\"single-img\"></image>\n    <view class=\"single-text-area\">\n        <text class=\"single-title\" selectable>\n            {{item.title}}\n        </text>\n        <view s-if=\"{{item.tags}}\" class=\"tag-area\">\n            <text s-for=\"tag in item.tags\" class=\"{{tag.className}}\">\n                {{tag.content}}\n            </text>\n        </view>\n    </view>\n</view>\n<button on-bindtap=\"eventHappen('tap', $event, 'loadMore', '')\">\n    \u70B9\u51FB\u52A0\u8F7D\u66F4\u591A\n</button>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);