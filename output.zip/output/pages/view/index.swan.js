"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view hover-class=\"hoverstate\">\n    <text>\u7236\u7EA7view\u7EC4\u4EF6\u4E2D\u7684\u6587\u5B57</text>\n\n    <view hover-class=\"none\" hover-stop-propagation=\"true\" class=\"item\">\n        <text>hover-class\u5C5E\u6027\u4E3Anone\uFF0C\u5F53\u524Dview\u6309\u4E0B\u53BB\u6CA1\u6709\u70B9\u51FB\u6001\u6548\u679C</text>\n    </view>\n\n    <view hover-class=\"hoverstate\" hover-stop-propagation=\"true\" class=\"item\" >\n        <text>\u6709hover-class\u5C5E\u6027\uFF0C\u6309\u4E0B\u51FA\u73B0\u70B9\u51FB\u6001</text>\n    </view>\n    \n    <view hover-class=\"hoverstate\" hover-stop-propagation=\"true\" class=\"item\">\n        <text>\u70B9\u51FB\u8BE5\u6587\u672C\uFF0C\u7956\u5148\u8282\u70B9\u4E0D\u4F1A\u51FA\u73B0\u70B9\u51FB\u6001</text>\n    </view>\n\n    <view hover-class=\"hoverstate\" class=\"item\">\n        <text>\u70B9\u51FB\u8BE5\u6587\u672C\uFF0C\u7956\u5148\u8282\u70B9\u4F1A\u51FA\u73B0\u70B9\u51FB\u6001</text>\n    </view>\n\n     <view hover-class=\"hoverstate\" hover-stop-propagation=\"false\"  class=\"item\">\n        <text>\u70B9\u51FB\u8BE5\u6587\u672C\uFF0C\u7956\u5148\u8282\u70B9\u4F1A\u51FA\u73B0\u70B9\u51FB\u6001 false</text>\n    </view>\n\n    <view hover-class=\"hoverstate\"  hover-stop-propagation=\"true\" hover-start-time=\"2000\" class=\"item\">\n        <text>\u70B9\u51FB\u8BE5\u6587\u672C\u540E,\u8BE5view 2s\u540E\u51FA\u73B0\u70B9\u51FB\u6001</text>\n    </view>\n\n    <view hover-class=\"hoverstate\" hover-stop-propagation=\"true\"  hover-stay-time=\"2000\" class=\"item\" >\n        <text>\u677E\u5F00\u8BE5\u6587\u672C\u540E\uFF0C\u8BE5view\u70B9\u51FB\u6001\u7EE7\u7EED\u4FDD\u63012s</text>\n    </view>\n\n    <view hover-class=\"hoverstate\"  hover-stop-propagation=\"true\" hover-start-time=\"2000\" hover-stay-time=\"1000\" class=\"item\">\n        <text>\u70B9\u51FB\u8BE5\u6587\u672C\u540E,\u8BE5view 2s\u540E\u51FA\u73B0\u70B9\u51FB\u6001\uFF0C\u677E\u5F00\u540E\uFF0C\u70B9\u51FB\u6001\u4FDD\u63012s</text>\n    </view>\n</view>\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);