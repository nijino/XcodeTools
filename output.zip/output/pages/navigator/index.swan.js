"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"swan-demo\">\n    <text>\u4E0B\u9762\u6D4B\u8BD5\u5BFC\u822A\u76F8\u5173\u5C5E\u6027</text>\n    <navigator url=\"pages/navigator/navigator?title=navigate\" hover-class=\"navigator-hover\" class=\"item\">\u9ED8\u8BA4\u8DF3\u8F6C\u65B9\u5F0F\uFF08\u8DF3\u8F6C\u5230\u65B0\u9875\u9762\uFF0C\u6700\u591A\u8DF35\u7EA7\uFF09</navigator>\n    <navigator url=\"pages/navigator/navigator?title=navigate\" open-type=\"navigateTo\" hover-class=\"navigator-hover\" class=\"item\">navigatetTo\u8DF3\u8F6C\u5230\u65B0\u9875\u9762</navigator>\n    <navigator url=\"pages/detail/detail/?title=redirect\" open-type=\"redirect\" hover-class=\"navigator-hover\" class=\"item\">redirect\u5728\u5F53\u524D\u9875\u6253\u5F00</navigator>\n    <navigator url=\"pages/api/api\" open-type=\"switchTab\" hover-class=\"navigator-hover\" class=\"item\">switchTab\u5207\u6362Tab</navigator>\n    <navigator url=\"pages/testview/testview\" open-type=\"relaunch\" hover-class=\"navigator-hover\" class=\"item\">relaunch\u91CD\u542Ftestview\u9875\u9762</navigator>\n    \n    <navigator open-type=\"navigateBack\" hover-class=\"navigator-hover\" class=\"item\">\u56DE\u9000\u4E00\u7EA7\uFF0Cdelta\u9ED8\u8BA4\u503C</navigator>\n    <navigator open-type=\"navigateBack\" delta=\"1\" hover-class=\"navigator-hover\" class=\"item\" >\u56DE\u9000\u4E00\u7EA7\uFF0Cdelta=1</navigator>\n    <navigator open-type=\"navigateBack\" delta=\"2\" hover-class=\"navigator-hover\" class=\"item\">\u56DE\u9000\u4E24\u7EA7</navigator>\n    <navigator  open-type=\"navigateBack\" delta=\"10\" hover-class=\"navigator-hover\" class=\"item\">\u56DE\u9000\u5341\u7EA7</navigator>\n\n</view>\n\n\n<view hover-class=\"view-hover\">\n\n    <text>\u4E0B\u9762\u6D4B\u8BD5\u70B9\u51FB\u6001\u76F8\u5173\u5C5E\u6027</text>\n\n    <navigator url=\"pages/detail/detail/?title=redirect\" open-type=\"redirect\" hover-class=\"navigator-hover\" hover-stop-propagation=\"true\" hover-start-time=\"2000\" class=\"item\">\u70B9\u51FB2s\u540E\u51FA\u73B0\u70B9\u51FB\u6001</navigator>\n    <navigator url=\"pages/detail/detail/?title=redirect\" open-type=\"redirect\" hover-class=\"navigator-hover\" hover-stop-propagation=\"true\" hover-stay-time=\"2000\" class=\"item\">\u677E\u5F00\u540E\u70B9\u51FB\u6001\u4FDD\u63012s</navigator>\n\n\n    <navigator url=\"pages/detail/detail?title=navigate\" open-type=\"navigateTo\" hover-class=\"navigator-hover\" hover-stop-propagation=\"false\" class=\"item\">\u8DF3\u8F6C\u5230\u65B0\u9875\u9762\uFF0C\u7236\u7EC4\u4EF6\u51FA\u73B0\u70B9\u51FB\u6001 false</navigator>\n    <navigator url=\"pages/detail/detail?title=navigate\" open-type=\"navigateTo\" hover-class=\"navigator-hover\" class=\"item\">\u8DF3\u8F6C\u5230\u65B0\u9875\u9762\uFF0C\u7236\u7EC4\u4EF6\u51FA\u73B0\u70B9\u51FB\u6001</navigator>\n    <navigator url=\"pages/detail/detail?title=navigate\" open-type=\"navigateTo\" hover-class=\"navigator-hover\" hover-stop-propagation=\"true\" class=\"item\">\u8DF3\u8F6C\u5230\u65B0\u9875\u9762\uFF0C\u7236\u7EC4\u4EF6\u4E0D\u51FA\u73B0\u70B9\u51FB\u6001</navigator>\n\n    <navigator url=\"pages/detail/detail/?title=redirect\" open-type=\"redirect\" hover-class=\"navigator-hover\" hover-stop-propagation=\"true\" class=\"item\">\u5728\u5F53\u524D\u9875\u6253\u5F00\uFF0C\u7236\u7EC4\u4EF6\u4E0D\u51FA\u73B0\u70B9\u51FB\u6001</navigator>\n    <navigator url=\"pages/detail/detail/?title=redirect\" open-type=\"redirect\" hover-class=\"navigator-hover\" hover-stop-propagation=\"false\" class=\"item\">\u5728\u5F53\u524D\u9875\u6253\u5F00,\u7236\u7EC4\u4EF6\u51FA\u73B0\u70B9\u51FB\u6001  false</navigator>\n    <navigator url=\"pages/detail/detail/?title=redirect\" open-type=\"redirect\" hover-class=\"navigator-hover\" class=\"item\">\u5728\u5F53\u524D\u9875\u6253\u5F00\uFF0C\u7236\u7EC4\u4EF6\u51FA\u73B0\u70B9\u51FB\u6001</navigator>\n</view>\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);