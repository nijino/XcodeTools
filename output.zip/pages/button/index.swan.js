"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view hover-class=\"view-hover\" class=\"view-border\">\n    <text>\u7236\u7EC4\u4EF6\u6709hover-class</text>\n    <button hover-stop-propagation=\"true\" hover-class=\"hoverstate\" > \u9ED8\u8BA4\u6837\u5F0F\u6309\u94AE\uFF08\u81EA\u5B9A\u4E49\u7684\u70B9\u51FB\u6001)</button>\n    <button type=\"primary\" hover-stop-propagation=\"true\"> primary\u6309\u94AE </button>\n    <button type=\"warn\" hover-stop-propagation=\"true\"> warn \u6309\u94AE </button>\n    <button type=\"primary\"  plain=\"true\" hover-stop-propagation=\"true\">plain=\"true\" \u9542\u7A7A\u6309\u94AE</button>\n    <button type=\"primary\" disabled=\"true\">\u4E0D\u53EF\u70B9\u51FB</button>\n    <button type=\"primary\" hover-stop-propagation=\"true\">\u53EF\u70B9\u51FB</button>\n    <button type=\"warn\">\u7236\u7EC4\u4EF6\u51FA\u73B0\u70B9\u51FB\u6837\u5F0F</button>\n    <button hover-stop-propagation=\"true\" hover-class=\"hoverstate\" hover-start-time=\"2000\">\u6309\u4E0B\u540E2s\u51FA\u73B0\u70B9\u51FB\u6001\uFF08\u81EA\u5B9A\u4E49\u7684\u70B9\u51FB\u6001\uFF09</button>\n    <button hover-stop-propagation=\"true\" hover-stay-time=\"2000\">\u677E\u5F00\u540E\u4FDD\u6301\u70B9\u51FB\u60012s</button>\n\n\n    <button hover-stop-propagation=\"true\" open-type=\"share\">\u70B9\u51FB\u5206\u4EAB</button>\n    <button hover-stop-propagation=\"true\" open-type=\"getUserInfo\" bind:getuserinfo=\"getUserInfo\">\u70B9\u51FB\u83B7\u53D6\u7528\u6237\u4FE1\u606F</button>\n    <button hover-stop-propagation=\"true\" open-type=\"getPhoneNumber\" bind:getphonenumber=\"getPhoneNumber\">\u70B9\u51FB\u83B7\u53D6\u7528\u6237\u624B\u673A\u53F7</button>\n\n    <view class=\"center\">\n        <button size=\"mini\" style=\"width:100px\" hover-stop-propagation=\"true\"> \u6309\u94AE </button>\n        <button size=\"mini\" type=\"primary\" style=\"width:100px\"  hover-stop-propagation=\"true\"> \u6309\u94AE </button>\n        <button size=\"mini\" type=\"warn\" style=\"width:100px\"  hover-stop-propagation=\"true\"> \u6309\u94AE </button>\n    </view>\n</view>\n\n<view class=\"view-border\">\n    <text>\u7236\u7EC4\u4EF6\u6CA1\u6709hover-class</text>\n    <button> \u9ED8\u8BA4\u6837\u5F0F\u6309\u94AE</button>\n    <button type=\"primary\"> primary</button>\n    <button type=\"primary\" plain=\"true\">\u9542\u7A7A\u6309\u94AE</button>\n    <button type=\"warn\"> warn</button>\n    <button disabled=\"true\">\u4E0D\u53EF\u70B9\u51FB</button>\n    <button hover-class=\"none\">\u6309\u4E0B\u6CA1\u6709\u70B9\u51FB\u6001</button>\n    <button hover-start-time=\"1000\">\u6309\u4E0B1s\u540E\u51FA\u73B0\u70B9\u51FB\u6001</button>\n    <button hover-stay-time=\"2000\">\u677E\u5F002s\u540E\u70B9\u51FB\u6001\u6D88\u5931</button>\n    <button size=\"mini\" style=\"width:100px\" > \u6309\u94AE </button>\n    <button size=\"mini\" type=\"primary\" style=\"width:100px\"> \u6309\u94AE </button>\n    <button size=\"mini\" type=\"warn\" style=\"width:100px\"> \u6309\u94AE </button>\n</view>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);