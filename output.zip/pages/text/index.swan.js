"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
				_inherits(Index, _SwanBase);

				function Index(options) {
								_classCallCheck(this, Index);

								return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
				}

				return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view>\n \t<view class=\"item\">\n\t     <text>\u6587\u672C\u9ED8\u8BA4\u4E0D\u53EF\u9009</text>\n\t</view>\n\t<view class=\"item\">\n\t     <text selectable>\u6587\u672C\u53EF\u4EE5\u9009\u62E9</text>\n\t</view>\n\t<view class=\"item\">\n\t     <text space=\"emsp\">\u4E0D\u663E\u793A  \u8FDE\u7EED  \u7A7A\u683C</text>\n\t</view>\n\t<view class=\"item\">\n\t    <text sapce=\"nbsp\">\u663E\u793A  \u8FDE\u7EED  \u7A7A\u683C</text>\n\t</view>\n\t<view class=\"item\">\n\t     <text>\u4E0D\u89E3\u7801\uFF1A&nbsp; &lt; &gt; &amp; &apos; &ensp; &emsp;@</text>\n\t</view>\n\t<view class=\"item\">\n\t    <text decode=\"true\">\u89E3\u7801\uFF1A&nbsp; &lt; &gt; &amp; &apos; &ensp; &emsp;@</text>\n\t</view>\n\t<view class=\"item\">\n\t    <text><\u7236\u7EA7text<text class=\"subtext\">text\u5D4C\u5957\u5B50text\u7EC4\u4EF6</text>\u7236\u7EA7text></text>\n\t</view>\n</view>\n\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);