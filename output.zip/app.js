/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(1);
__webpack_require__(2);
__webpack_require__(3);
__webpack_require__(4);
__webpack_require__(5);
__webpack_require__(6);
__webpack_require__(7);
__webpack_require__(8);
__webpack_require__(9);
__webpack_require__(10);
__webpack_require__(11);
__webpack_require__(12);
__webpack_require__(13);
__webpack_require__(14);
__webpack_require__(15);
__webpack_require__(16);
__webpack_require__(17);
__webpack_require__(18);
__webpack_require__(19);
__webpack_require__(20);
__webpack_require__(21);
__webpack_require__(22);
__webpack_require__(23);
__webpack_require__(24);
__webpack_require__(25);
__webpack_require__(26);
__webpack_require__(27);
__webpack_require__(28);
__webpack_require__(29);
__webpack_require__(30);
__webpack_require__(31);
__webpack_require__(32);
__webpack_require__(33);
__webpack_require__(34);
__webpack_require__(35);
__webpack_require__(36);
__webpack_require__(37);
__webpack_require__(38);
__webpack_require__(39);
__webpack_require__(40);
__webpack_require__(41);
__webpack_require__(42);
__webpack_require__(43);
__webpack_require__(44);
__webpack_require__(45);
__webpack_require__(46);
__webpack_require__(47);
__webpack_require__(48);
__webpack_require__(49);
__webpack_require__(50);
__webpack_require__(51);
__webpack_require__(52);
__webpack_require__(53);
__webpack_require__(54);
__webpack_require__(55);
__webpack_require__(56);
module.exports = __webpack_require__(57);


/***/ }),
/* 1 */
/***/ (function(module, exports) {

PageDefine('pages/testview/testview', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */

/* eslint-disable */

Page({
    data: {
        items: [{
            cortName: '界面',
            cortList: [{
                subName: '视图容器',
                subList: [{
                    id: 'view'
                }, {
                    id: 'scroll-view'
                }, {
                    id: 'swiper'
                }]
            }, {
                subName: '基础内容',
                subList: [{
                    id: 'icon'
                }, {
                    id: 'text'
                }]
            }, {
                subName: '表单组件',
                subList: [{
                    id: 'button'
                }]
            }, {
                subName: '导航',
                subList: [{
                    id: 'navigator'
                }]
            }, {
                subName: '媒体组件',
                subList: [{
                    id: 'image'
                }]
            }, {
                subName: '地图（待补充）',
                subList: []
            }, {
                subName: '画布（待补充）',
                subList: []
            }, {
                subName: '开放能力',
                subList: [{
                    id: 'webview'
                }]
            }]
        }]
    },

    oneItemClick: function oneItemClick(e) {
        // console.log(e.target);
        var viewName = e.target.dataset.id;
        console.log("will navigateTo :" + viewName);
        swan.navigateTo({
            url: 'pages/' + viewName + '/' + viewName
        });
    },

    toggleClick: function toggleClick(e) {}
});});

/***/ }),
/* 2 */
/***/ (function(module, exports) {

PageDefine('pages/view/view', function (Page) {"use strict";

/**
 * @file test for view component
 * @author hujie08(hujie08@baidu.com)
 */
Page({});});

/***/ }),
/* 3 */
/***/ (function(module, exports) {

PageDefine('pages/scroll-view/scroll-view', function (Page) {'use strict';

/**
 * @file test scroll-view componnent
 * @author hujie(hujie08@baidu.com)
 */

Page({
    data: {
        data: {
            toView: 'view4',
            scrollTop: 100
        }
    },

    upper: function upper() {
        window.swan.showToast({
            duration: 1000,
            title: '到顶了（根据设置的到顶阈值）',
            icon: 'success'
        });
    },

    lower: function lower() {
        window.swan.showToast({
            duration: 1000,
            title: '到底了（根据设置的到底阈值）',
            icon: 'success'
        });
    },

    myscroll: function myscroll(e) {
        console.log('获取滚动事件的详细信息e.detail：' + e.detail);
        console.dir(e.detail);
        window.swan.showToast({
            duration: 100,
            title: '触发滚动事件',
            icon: 'success'
        });
    }

});});

/***/ }),
/* 4 */
/***/ (function(module, exports) {

PageDefine('pages/swiper/swiper', function (Page) {'use strict';

/**
 * @file demo page for swan
 * @author hzz780(huangzongzhe@baidu.com)
 */
Page({
    data: {
        items: ['http://img02.tooopen.com/images/20150928/tooopen_sy_143912755726.jpg', 'http://img06.tooopen.com/images/20160818/tooopen_sy_175866434296.jpg', 'http://img06.tooopen.com/images/20160818/tooopen_sy_175833047715.jpg'],
        current: 2
    },

    swiperChange: function swiperChange(e) {
        console.log('swiperChange', e);
    }
    // ,
    // oneItemClick: function() {
    //     this.setData('current', 2);
    //     window.zzsetData = this.setData;
    //     console.log('current', 2);
    // }
});});

/***/ }),
/* 5 */
/***/ (function(module, exports) {

PageDefine('pages/icon/icon', function (Page) {"use strict";});

/***/ }),
/* 6 */
/***/ (function(module, exports) {

PageDefine('pages/text/text', function (Page) {"use strict";

/**
 * @file demo page for swan
 * @author houyu(houyu01@baidu.com)
 */
Page({});});

/***/ }),
/* 7 */
/***/ (function(module, exports) {

PageDefine('pages/button/button', function (Page) {'use strict';

/**
 * @file test for button component f
 * @author hujie08@baidu.com
 */
Page({
    getUser: function getUser(e) {
        console.log('getUserInfo: ', e);
        window.swan.showToast({
            title: 'mock的用户',
            icon: 'success',
            duration: 1000
        });
    },

    getNumber: function getNumber(e) {
        console.log('getPhoneNumber: ', e);
        window.swan.showToast({
            title: 'mock的电话',
            icon: 'success',
            duration: 1000
        });
    },

    onShareAppMessage: function onShareAppMessage(options) {
        console.log('share: ' + options.webViewUrl);
        window.swan.showToast({
            title: '调用了分享',
            icon: 'success',
            duration: 1000
        });
    }
});});

/***/ }),
/* 8 */
/***/ (function(module, exports) {

PageDefine('pages/navigator/navigator', function (Page) {"use strict";

/**
 * @file test scroll-view componnent
 * @author hujie(hujie08@baidu.com)
 */
Page({
    onLoad: function onLoad(options) {
        this.setData({
            title: options.title
        });
    }
});});

/***/ }),
/* 9 */
/***/ (function(module, exports) {

PageDefine('pages/image/image', function (Page) {'use strict';

/**
 * @file demo page for swan
 * @author houyu(houyu01@baidu.com)
 */
Page({
    data: {
        page: {
            localJpegPath: '../../images/image1.jpeg',
            localJpgPath: '../../images/image5.jpg',
            localPngPath: '../../images/image4.png',
            webImgPath: 'https://www.google.com.hk/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=0ahUKEwjXnoD6wK7YAhVLm5QKHZv_AnEQjRwIBw&url=%68%74%74%70%3a%2f%2f%36%39%39%70%69%63%2e%63%6f%6d%2f%74%75%70%69%61%6e%2f%68%61%69%6c%69%2e%68%74%6d%6c&psig=AOvVaw2jjhuUrWgQcyN4Ub6Fb0BY&ust=1514611156832353'
        }
    },

    error: function error(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: '加载图片出错',
            duration: 1000
        });
    },

    load: function load(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: '加载图片完毕',
            duration: 1000
        });
    },

    lazyerror: function lazyerror(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: 'lazyload 加载图片出错',
            duration: 1000
        });
    },

    lazyload: function lazyload(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: 'lazyload 加载图片完毕',
            duration: 1000
        });
    }
});});

/***/ }),
/* 10 */
/***/ (function(module, exports) {

PageDefine('pages/webview/webview', function (Page) {"use strict";

/**
 * @file test for swan
 * @author hujie08(hujie08@baidu.com)
 */
Page({});});

/***/ }),
/* 11 */
/***/ (function(module, exports) {

PageDefine('pages/index/index', function (Page) {'use strict';

/**
 * @file demo page for swan
 * @author houyu(houyu01@baidu.com)
 */
Page({
    data: {
        items: [{
            title: '领着过万工资，却活出民工生活，住在西二旗附近的低调“百度”人',
            imgsrc: 'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=443817272,857019512&fm=58',
            tags: [{
                content: '新华网',
                className: 'rn-icon-normal'
            }, {
                content: '17:44',
                className: 'rn-icon-normal'
            }]
        }, {
            title: '领着过万工资，却活出民工生活，住在西二旗附近的低调“百度”人',
            imgsrc: 'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=443817272,857019512&fm=58'
        }]
    },

    oneItemClick: function oneItemClick(e) {
        swan.navigateTo({
            'url': 'pages/detail/detail'
        });
    },

    loadMore: function loadMore() {
        var insertItem = {
            title: '程序猿喜迎佳节，1024万人空巷，都去找三好？？？',
            imgsrc: 'https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1024874097,1179143910&fm=173&s=EF926D8DDB733282513984970300C0C2&w=218&h=146&img.JPEG',
            tags: [{
                content: '新华网',
                className: 'rn-icon-normal'
            }, {
                content: '17:44',
                className: 'rn-icon-normal'
            }]
        };
        this.dataPush('items', insertItem);
    },

    oneItemTouchStart: function oneItemTouchStart() {
        console.log('oneItemTouchStart');
    },

    oneItemTouchEnd: function oneItemTouchEnd() {
        console.log('oneItemTouchEnd');
    },

    onLoad: function onLoad() {
        console.log('page-init');
    },

    onReady: function onReady() {
        console.log('onReady');
    },

    onShow: function onShow() {
        console.log('onShow');
    },

    onHide: function onHide() {
        console.log('onHide');
    }
});});

/***/ }),
/* 12 */
/***/ (function(module, exports) {

PageDefine('pages/detail/detail', function (Page) {'use strict';

/**
 * @file demo page for swan
 * @author houyu(houyu01@baidu.com)
 */
Page({
    data: {
        page: {
            title: '领着过万工资，却活出民工生活，住在西二旗附近的低调“百度”人',
            content: '还没有走出大学校门的时候就听师兄师姐在嘴里讨论着”BAT“，那个时候于传说中的”BAT“还抱着懵懂的感觉。什么是BAT，到后来才知道了，原来BAT就是百度，腾讯，阿里巴巴三大互联网公司。其实，那个时候还不明白毕业了在这几家公司工作到底有什么让人羡慕的地方，为什么周围的人对这三家公司是如此的推崇之至。直到从网上看到的新闻，直到自己也面临找工作的时候才明白，BAT意味着什么。'
        }
    }
});});

/***/ }),
/* 13 */
/***/ (function(module, exports) {

PageDefine('pages/api/api', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */

/* eslint-disable */

Page({
    data: {
        items: [{
            cortName: '测试boxjs',
            cortList: [{
                subName: '测试boxjs',
                subList: [{
                    id: 'getSlaveIdSync'
                }, {
                    id: 'picker'
                }, {
                    id: 'getPhoneNumber'
                }]
            }]
        }, {
            cortName: '位置',
            cortList: [{
                subName: '获取位置',
                subList: [{
                    id: 'getLocation'
                }]
            }]
        }, {
            cortName: '开放接口',
            cortList: [{
                subName: '授权',
                subList: [{
                    id: 'authorize'
                }]
            }, {
                subName: '登录',
                subList: [{
                    id: 'login'
                }, {
                    id: 'checkSession'
                }]
            }, {
                subName: '用户信息',
                subList: [{
                    id: 'getUserInfo'
                }]
            }, {
                subName: '支付',
                subList: [{
                    id: 'requestPayment'
                }, {
                    id: 'requestAliPayment'
                }]
            }, {
                subName: '设置',
                subList: [{
                    id: 'getSetting'
                }, {
                    id: 'openSetting'
                }]
            }, {
                subName: '分享',
                subList: [{
                    id: 'openShare'
                }]
            }]
        }, {
            cortName: '界面',
            cortList: [{
                subName: '交互反馈',
                subList: [{
                    id: 'showActionSheet'
                }, {
                    id: 'showModal'
                }, {
                    id: 'showToast'
                }, {
                    id: 'showLoading'
                }]
            }, {
                subName: '导航',
                subList: [{
                    id: 'navigateTo'
                }, {
                    id: 'redirectTo'
                }, {
                    id: 'switchTab'
                }, {
                    id: 'navigateBack'
                }, {
                    id: 'reLaunch'
                }, {
                    id: 'webView'
                }]
            }, {
                subName: '设置导航条',
                subList: [{
                    id: 'setNavigationBarColor'
                }, {
                    id: 'setNavigationBarTitle'
                }, {
                    id: 'showNavigationBarLoading'
                }]
            }, {
                subName: '下拉刷新',
                subList: [{
                    id: 'startPullDownRefresh'
                }]
            }]
        }, {
            cortName: '设备',
            cortList: [{
                subName: '系统信息',
                subList: [{
                    id: 'getSystemInfo'
                }, {
                    id: 'getSystemInfoSync'
                }]
            }, {
                subName: '网络状态',
                subList: [{
                    id: 'getNetworkType'
                }]
            }, {
                subName: '拨打电话',
                subList: [{
                    id: 'makePhoneCall'
                }]
            }, {
                subName: '剪贴板',
                subList: [{
                    id: 'setClipboardData'
                }]
            }]
        }, {
            cortName: '媒体',
            cortList: [{
                subName: '图片',
                subList: [{
                    id: 'previewImage'
                }]
            }]
        }, {
            cortName: '网络',
            cortList: [{
                subName: '发起请求',
                subList: [{
                    id: 'request'
                }]
            }]
        }],
        noSubapi: [{
            cortName: '数据缓存',
            cortList: [{
                id: 'getStorage'
            }, {
                id: 'getStorageSync'
            }, {
                id: 'getStorageInfo'
            }, {
                id: 'getStorageInfoSync'
            }, {
                id: 'setStorage'
            }, {
                id: 'setStorageSync'
            }, {
                id: 'removeStorage'
            }, {
                id: 'removeStorageSync'
            }, {
                id: 'clearStorage'
            }, {
                id: 'clearStorageSync'
            }]
        }]
    },

    oneItemClick: function oneItemClick(e) {
        var apiName = e.target.dataset.id;
        swan.navigateTo({
            url: 'pages/' + apiName + '/' + apiName
        });
    },
    toggleClick: function toggleClick(e) {}
});});

/***/ }),
/* 14 */
/***/ (function(module, exports) {

PageDefine('pages/getNetworkType/getNetworkType', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getNetworkType'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getNetworkType({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log(JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 15 */
/***/ (function(module, exports) {

PageDefine('pages/showNavigationBarLoading/showNavigationBarLoading', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'showNavigationBarLoading'
        },
        item2: {
            id: 'hideNavigationBarLoading'
        }
    },

    showClick: function showClick() {
        window.swan.showNavigationBarLoading();
    },

    hideClick: function hideClick() {
        window.swan.hideNavigationBarLoading();
    }
});});

/***/ }),
/* 16 */
/***/ (function(module, exports) {

PageDefine('pages/setClipboardData/setClipboardData', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'setClipboardData'
        },
        item2: {
            id: 'getClipboardData'
        }
    },

    setClipboardData: function setClipboardData() {
        window.swan.setClipboardData({
            data: 'baidu',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    getClipboardData: function getClipboardData() {
        window.swan.getClipboardData({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 17 */
/***/ (function(module, exports) {

PageDefine('pages/getSystemInfo/getSystemInfo', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSystemInfo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getSystemInfo({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 18 */
/***/ (function(module, exports) {

PageDefine('pages/getSystemInfoSync/getSystemInfoSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSystemInfoSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getSystemInfoSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('getSystemInfoSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 19 */
/***/ (function(module, exports) {

PageDefine('pages/makePhoneCall/makePhoneCall', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'makePhoneCall'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.makePhoneCall({
            phoneNumber: '1234567890'
        });
    }
});});

/***/ }),
/* 20 */
/***/ (function(module, exports) {

PageDefine('pages/navigateBack/navigateBack', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'navigateBack'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.navigateBack({
            delta: 1,
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 21 */
/***/ (function(module, exports) {

PageDefine('pages/navigateTo/navigateTo', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'navigateTo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.navigateTo({
            url: 'pages/navigateTo/navigateTo',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 22 */
/***/ (function(module, exports) {

PageDefine('pages/redirectTo/redirectTo', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'redirectTo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.redirectTo({
            url: 'pages/detail/detail?key=value',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 23 */
/***/ (function(module, exports) {

PageDefine('pages/reLaunch/reLaunch', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'reLaunch'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.reLaunch({
            url: 'pages/api/api',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 24 */
/***/ (function(module, exports) {

PageDefine('pages/setNavigationBarColor/setNavigationBarColor', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setNavigationBarColor'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.setNavigationBarColor({
            frontColor: '#ffffff',
            backgroundColor: '#0099cc',
            animation: {
                duration: 500,
                timingFunc: 'easeIn'
            },
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 25 */
/***/ (function(module, exports) {

PageDefine('pages/showModal/showModal', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'showModal'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.showModal({
            title: 'wowowo',
            content: '提示的内容',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 26 */
/***/ (function(module, exports) {

PageDefine('pages/showActionSheet/showActionSheet', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'showActionSheet'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.showActionSheet({
            itemList: ['我', '是', '谁'],
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 27 */
/***/ (function(module, exports) {

PageDefine('pages/switchTab/switchTab', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'switchTab'
        }
    },

    oneItemClick: function oneItemClick() {
        console.log('switchtabClick');
        window.swan.switchTab({
            url: 'pages/index/index',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 28 */
/***/ (function(module, exports) {

PageDefine('pages/setNavigationBarTitle/setNavigationBarTitle', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setNavigationBarTitle'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.setNavigationBarTitle({
            title: '我是标题',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 29 */
/***/ (function(module, exports) {

PageDefine('pages/setStorage/setStorage', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.setStorage({
            key: 'rzh',
            data: '111',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 30 */
/***/ (function(module, exports) {

PageDefine('pages/setStorageSync/setStorageSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.setStorageSync('rzh', '1234');
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('setStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 31 */
/***/ (function(module, exports) {

PageDefine('pages/getStorage/getStorage', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getStorage({
            key: 'rzh',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 32 */
/***/ (function(module, exports) {

PageDefine('pages/getStorageSync/getStorageSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getStorageSync('rzh');
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('getStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 33 */
/***/ (function(module, exports) {

PageDefine('pages/getStorageInfo/getStorageInfo', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorageInfo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getStorageInfo({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 34 */
/***/ (function(module, exports) {

PageDefine('pages/getStorageInfoSync/getStorageInfoSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorageInfoSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getStorageInfoSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('getStorageInfoSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 35 */
/***/ (function(module, exports) {

PageDefine('pages/removeStorage/removeStorage', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'removeStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.removeStorage({
            key: 'rzh',
            success: function success(res) {
                window.swan.showToast({
                    title: '删除返回结果:::' + JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 36 */
/***/ (function(module, exports) {

PageDefine('pages/removeStorageSync/removeStorageSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'removeStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.removeStorageSync('rzh');
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('removeStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 37 */
/***/ (function(module, exports) {

PageDefine('pages/clearStorage/clearStorage', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'clearStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.clearStorage();
    }
});});

/***/ }),
/* 38 */
/***/ (function(module, exports) {

PageDefine('pages/clearStorageSync/clearStorageSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'clearStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.clearStorageSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('clearStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 39 */
/***/ (function(module, exports) {

PageDefine('pages/request/request', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'request'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.request({
            url: 'https://14592619.qcloud.la/testRequest',
            dataType: 'json',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 40 */
/***/ (function(module, exports) {

PageDefine('pages/previewImage/previewImage', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'previewImage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.previewImage({
            urls: ['https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1844830708,4171352519&fm=173&s=72E225E004EA85551C46C48C0300F0CB&w=600&h=337&img.JPEG', 'https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1844830708,4171352519&fm=173&s=72E225E004EA85551C46C48C0300F0CB&w=600&h=337&img.JPEG'],
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 41 */
/***/ (function(module, exports) {

PageDefine('pages/showToast/showToast', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'showToast'
        },
        item2: {
            id: 'hideToast'
        }
    },

    showClick: function showClick() {
        window.swan.showToast({
            duration: 5000,
            title: 'showToast',
            icon: 'success'
        });
    },

    hideClick: function hideClick() {
        window.swan.hideToast();
    }
});});

/***/ }),
/* 42 */
/***/ (function(module, exports) {

PageDefine('pages/showLoading/showLoading', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'showLoading'
        },
        item2: {
            id: 'hideLoading'
        }
    },

    showClick: function showClick() {
        window.swan.showLoading({
            title: 'loading'
        });
    },

    hideClick: function hideClick() {
        window.swan.hideLoading();
    }
});});

/***/ }),
/* 43 */
/***/ (function(module, exports) {

PageDefine('pages/startPullDownRefresh/startPullDownRefresh', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'startPullDownRefresh'
        },
        item2: {
            id: 'stopPullDownRefresh'
        }
    },

    showClick: function showClick() {
        window.swan.startPullDownRefresh();
    },

    hideClick: function hideClick() {
        window.swan.stopPullDownRefresh();
    }
});});

/***/ }),
/* 44 */
/***/ (function(module, exports) {

PageDefine('pages/authorize/authorize', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items1: {
            id: 'authorize-userInfo'
        },
        item2: {
            id: 'authorize-userLocation'
        },
        item3: {
            id: 'authorize-mobile'
        }
    },

    auserInfo: function auserInfo() {
        window.swan.authorize({
            scope: 'scope.userInfo',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    auserLocation: function auserLocation() {
        window.swan.authorize({
            scope: 'scope.userLocation',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    amobile: function amobile() {
        window.swan.authorize({
            scope: 'scope.mobile',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 45 */
/***/ (function(module, exports) {

PageDefine('pages/getLocation/getLocation', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getLocation'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getLocation({
            type: 'wgs84',
            altitude: true,
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 46 */
/***/ (function(module, exports) {

PageDefine('pages/checkSession/checkSession', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'checkSession'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.checkSession({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 47 */
/***/ (function(module, exports) {

PageDefine('pages/getUserInfo/getUserInfo', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getUserInfo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getUserInfo({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 48 */
/***/ (function(module, exports) {

PageDefine('pages/getSetting/getSetting', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSetting'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getSetting({
            success: function success(res) {
                console.log(JSON.stringify(res));
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 49 */
/***/ (function(module, exports) {

PageDefine('pages/openSetting/openSetting', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'openSetting'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.openSetting({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 50 */
/***/ (function(module, exports) {

PageDefine('pages/login/login', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'login'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.login({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 51 */
/***/ (function(module, exports) {

PageDefine('pages/requestPayment/requestPayment', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'requestPayment'
        },
        name: '',
        amount: '',
        spno: '',
        returnurl: '',
        time: '',
        desc: '',
        sign: '',
        order: ''
    },

    orderClick: function orderClick(e) {
        this.setData('order', e.detail.value);
    },
    nameClick: function nameClick(e) {
        this.setData('name', e.detail.value);
    },
    amountClick: function amountClick(e) {
        this.setData('amount', e.detail.value);
    },
    returnClick: function returnClick(e) {
        this.setData('eturnurl', e.detail.value);
    },
    timeClick: function timeClick(e) {
        this.setData('time', e.detail.value);
    },
    descClick: function descClick(e) {
        this.setData('desc', e.detail.value);
    },
    signClick: function signClick(e) {
        this.setData('sign', e.detail.value);
    },
    spnoClick: function spnoClick(e) {
        this.setData('spno', e.detail.value);
    },
    oneItemClick: function oneItemClick(e) {
        window.swan.requestPayment({
            orderinfo: {
                'goods_name': encodeURIComponent(this.getData('name')),
                'total_amount': this.getData('amount'),
                'sp_no': this.getData('spno'),
                'return_url': encodeURIComponent(this.getData('returnurl')),
                debug: true,
                'order_create_time': this.getData('time'),
                'order_no': this.getData('order'),
                'goods_desc': this.getData('desc'),
                currency: '1',
                'input_charset': '1',
                sign: this.getData('sign'),
                'sign_method': '1'
            },
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 52 */
/***/ (function(module, exports) {

PageDefine('pages/requestAliPayment/requestAliPayment', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'requestAliPayment'
        },
        order: ''
    },

    orderClick: function orderClick(e) {
        this.setData('order', e.detail.value);
    },
    oneItemClick: function oneItemClick(e) {
        window.swan.requestAliPayment({
            orderinfo: this.getData('order'),
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 53 */
/***/ (function(module, exports) {

PageDefine('pages/openShare/openShare', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'openShare'
        }
    },

    addClick: function addClick() {
        document.addEventListener('sharebtn', function (e) {
            console.log('sharebtn');
            var url = 'https://po.baidu.com/act/tpl/index.html?t=guideapp&type=scheme&from=&channel=&iosScheme';
            var scheme = 'baiduboxapp://v18/swan/launch?appid=1';

            window.swan.openShare({
                mediaType: 'all',
                title: '小程序标题',
                content: '世界很复杂，百度更懂你',
                iconUrl: 'http://imgsrc.baidu.com/forum/pic/item/d9f9d72a6059252daecdfc36309b033b5bb5b92e.jpg',
                linkUrl: url + scheme + '&andCommand' + scheme,
                pannel: ['sinaweibo', 'weixin_friend', 'baiduhi'],
                type: 'url',
                path: '/pages/openShare/openShare',
                success: function success(res) {
                    window.swan.showToast({
                        title: JSON.stringify(res)
                    });
                    console.log(JSON.stringify(res));
                },
                fail: function fail(err) {
                    console.log(JSON.stringify(err));
                }
            });
        }, false);
    }
});});

/***/ }),
/* 54 */
/***/ (function(module, exports) {

PageDefine('pages/getSlaveIdSync/getSlaveIdSync', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSlaveIdSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getSlaveIdSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('success::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 55 */
/***/ (function(module, exports) {

PageDefine('pages/picker/picker', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items1: {
            id: 'date'
        },
        items2: {
            id: 'time'
        }
    },

    oneItemClick1: function oneItemClick1() {
        window.swan.openDatePickerView({
            start: '2017-01-01',
            end: '2017-12-31',
            value: '2017-12-28', // 默认选中时间
            mode: 'date',
            fields: 'day',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    oneItemClick2: function oneItemClick2() {
        window.swan.openDatePickerView({
            start: '00:01',
            end: '12:00',
            value: '11:00', // 默认选中时间
            mode: 'time',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 56 */
/***/ (function(module, exports) {

PageDefine('pages/getPhoneNumber/getPhoneNumber', function (Page) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getPhoneNumber'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getPhoneNumber({
            success: function success(res) {
                console.log(JSON.stringify(res));
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


//app.js
App({
    onLaunch: function onLaunch() {
        console.log('onLaunch');
    },

    globalData: {
        userInfo: 'user'
    }
});

/***/ })
/******/ ]);