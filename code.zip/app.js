/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(1);
__webpack_require__(2);
__webpack_require__(3);
__webpack_require__(4);
__webpack_require__(5);
__webpack_require__(6);
__webpack_require__(7);
__webpack_require__(8);
__webpack_require__(9);
__webpack_require__(10);
__webpack_require__(11);
__webpack_require__(12);
__webpack_require__(13);
__webpack_require__(14);
__webpack_require__(15);
__webpack_require__(16);
__webpack_require__(17);
__webpack_require__(18);
__webpack_require__(19);
__webpack_require__(20);
__webpack_require__(21);
__webpack_require__(22);
__webpack_require__(23);
__webpack_require__(24);
__webpack_require__(25);
__webpack_require__(26);
__webpack_require__(27);
__webpack_require__(28);
__webpack_require__(29);
__webpack_require__(30);
__webpack_require__(31);
__webpack_require__(32);
__webpack_require__(33);
__webpack_require__(34);
__webpack_require__(35);
__webpack_require__(36);
__webpack_require__(37);
__webpack_require__(38);
__webpack_require__(39);
__webpack_require__(40);
__webpack_require__(41);
__webpack_require__(42);
__webpack_require__(43);
__webpack_require__(44);
__webpack_require__(45);
__webpack_require__(46);
__webpack_require__(47);
__webpack_require__(48);
__webpack_require__(49);
__webpack_require__(50);
__webpack_require__(51);
__webpack_require__(52);
__webpack_require__(53);
__webpack_require__(54);
__webpack_require__(55);
__webpack_require__(56);
__webpack_require__(57);
__webpack_require__(58);
__webpack_require__(59);
__webpack_require__(60);
__webpack_require__(61);
__webpack_require__(62);
__webpack_require__(63);
__webpack_require__(64);
__webpack_require__(65);
__webpack_require__(66);
__webpack_require__(67);
__webpack_require__(68);
__webpack_require__(69);
__webpack_require__(70);
__webpack_require__(71);
__webpack_require__(72);
__webpack_require__(73);
__webpack_require__(74);
module.exports = __webpack_require__(75);


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


//app.js
App({
    onLaunch: function onLaunch() {
        console.log('onLaunch');
    },

    globalData: {
        userInfo: 'user'
    }
});

/***/ }),
/* 2 */
/***/ (function(module, exports) {

PageDefine('pages/testview/testview', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */

/* eslint-disable */

Page({
    data: {
        items: [{
            cortName: '界面',
            cortList: [{
                subName: '视图容器',
                subList: [{
                    id: 'view'
                }, {
                    id: 'scroll-view'
                }, {
                    id: 'swiper'
                }]
            }, {
                subName: '基础内容',
                subList: [{
                    id: 'icon'
                }, {
                    id: 'text'
                }]
            }, {
                subName: '表单组件',
                subList: [{
                    id: 'button'
                }]
            }, {
                subName: '导航',
                subList: [{
                    id: 'navigator'
                }]
            }, {
                subName: '媒体组件',
                subList: [{
                    id: 'image'
                }]
            }, {
                subName: '地图（待补充）',
                subList: []
            }, {
                subName: '画布（待补充）',
                subList: []
            }, {
                subName: '开放能力',
                subList: [{
                    id: 'webview'
                }]
            }]
        }]
    },

    oneItemClick: function oneItemClick(e) {
        // console.log(e.target);
        var viewName = e.target.dataset.id;
        console.log("will navigateTo :" + viewName);
        swan.navigateTo({
            url: 'pages/' + viewName + '/' + viewName
        });
    },

    toggleClick: function toggleClick(e) {}
});});

/***/ }),
/* 3 */
/***/ (function(module, exports) {

PageDefine('pages/view/view', function (Page, getApp) {"use strict";

/**
 * @file test for view component
 * @author hujie08(hujie08@baidu.com)
 */
Page({});});

/***/ }),
/* 4 */
/***/ (function(module, exports) {

PageDefine('pages/scroll-view/scroll-view', function (Page, getApp) {'use strict';

/**
 * @file test scroll-view componnent
 * @author hujie(hujie08@baidu.com)
 */

Page({
    data: {
        data: {
            toView: 'view4',
            scrollTop: 100
        }
    },

    upper: function upper() {
        window.swan.showToast({
            duration: 1000,
            title: '到顶了（根据设置的到顶阈值）',
            icon: 'success'
        });
    },

    lower: function lower() {
        window.swan.showToast({
            duration: 1000,
            title: '到底了（根据设置的到底阈值）',
            icon: 'success'
        });
    },

    myscroll: function myscroll(e) {
        console.log('获取滚动事件的详细信息e.detail：' + e.detail);
        console.dir(e.detail);
        window.swan.showToast({
            duration: 100,
            title: '触发滚动事件',
            icon: 'success'
        });
    }

});});

/***/ }),
/* 5 */
/***/ (function(module, exports) {

PageDefine('pages/swiper/swiper', function (Page, getApp) {'use strict';

/**
 * @file demo page for swan
 * @author hzz780(huangzongzhe@baidu.com)
 */
Page({
    data: {
        items: ['http://img02.tooopen.com/images/20150928/tooopen_sy_143912755726.jpg', 'http://img06.tooopen.com/images/20160818/tooopen_sy_175866434296.jpg', 'http://img06.tooopen.com/images/20160818/tooopen_sy_175833047715.jpg'],
        current: 2
    },

    swiperChange: function swiperChange(e) {
        console.log('swiperChange', e);
    }
    // ,
    // oneItemClick: function() {
    //     this.setData('current', 2);
    //     window.zzsetData = this.setData;
    //     console.log('current', 2);
    // }
});});

/***/ }),
/* 6 */
/***/ (function(module, exports) {

PageDefine('pages/icon/icon', function (Page, getApp) {"use strict";});

/***/ }),
/* 7 */
/***/ (function(module, exports) {

PageDefine('pages/text/text', function (Page, getApp) {"use strict";

/**
 * @file demo page for swan
 * @author houyu(houyu01@baidu.com)
 */
Page({});});

/***/ }),
/* 8 */
/***/ (function(module, exports) {

PageDefine('pages/button/button', function (Page, getApp) {'use strict';

/**
 * @file test for button component f
 * @author hujie08@baidu.com
 */
Page({
    getUser: function getUser(e) {
        console.log('getUserInfo: ', e);
        window.swan.showToast({
            title: 'mock的用户',
            icon: 'success',
            duration: 1000
        });
    },

    getNumber: function getNumber(e) {
        console.log('getPhoneNumber: ', e);
        window.swan.showToast({
            title: 'mock的电话',
            icon: 'success',
            duration: 1000
        });
    },

    onShareAppMessage: function onShareAppMessage(options) {
        console.log('share: ' + options.webViewUrl);
        window.swan.showToast({
            title: '调用了分享',
            icon: 'success',
            duration: 1000
        });
    }
});});

/***/ }),
/* 9 */
/***/ (function(module, exports) {

PageDefine('pages/navigator/navigator', function (Page, getApp) {"use strict";

/**
 * @file test scroll-view componnent
 * @author hujie(hujie08@baidu.com)
 */
Page({
    onLoad: function onLoad(options) {
        this.setData({
            title: options.title
        });
    }
});});

/***/ }),
/* 10 */
/***/ (function(module, exports) {

PageDefine('pages/image/image', function (Page, getApp) {'use strict';

/**
 * @file demo page for swan
 * @author houyu(houyu01@baidu.com)
 */
Page({
    data: {
        page: {
            localJpegPath: '../../images/image1.jpeg',
            localJpgPath: '../../images/image5.jpg',
            localPngPath: '../../images/image4.png',
            webImgPath: 'https://www.google.com.hk/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=0ahUKEwjXnoD6wK7YAhVLm5QKHZv_AnEQjRwIBw&url=%68%74%74%70%3a%2f%2f%36%39%39%70%69%63%2e%63%6f%6d%2f%74%75%70%69%61%6e%2f%68%61%69%6c%69%2e%68%74%6d%6c&psig=AOvVaw2jjhuUrWgQcyN4Ub6Fb0BY&ust=1514611156832353'
        }
    },

    error: function error(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: '加载图片出错',
            duration: 1000
        });
    },

    load: function load(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: '加载图片完毕',
            duration: 1000
        });
    },

    lazyerror: function lazyerror(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: 'lazyload 加载图片出错',
            duration: 1000
        });
    },

    lazyload: function lazyload(e) {
        console.log(e.detail);
        window.swan.showToast({
            title: 'lazyload 加载图片完毕',
            duration: 1000
        });
    }
});});

/***/ }),
/* 11 */
/***/ (function(module, exports) {

PageDefine('pages/webview/webview', function (Page, getApp) {"use strict";

/**
 * @file test for swan
 * @author hujie08(hujie08@baidu.com)
 */
Page({});});

/***/ }),
/* 12 */
/***/ (function(module, exports) {

PageDefine('pages/index/index', function (Page, getApp) {'use strict';

Page({
	openHome: function openHome(e) {
		swan.navigateTo({
			'url': 'pages/home/home'
		});
	},
	openFanice: function openFanice(e) {
		swan.navigateTo({
			'url': 'pages/fanice/fanice'
		});
	},
	openParams: function openParams(e) {
		swan.navigateTo({
			'url': 'pages/params/params'
		});
	},
	openFreeCall: function openFreeCall(e) {
		swan.navigateTo({
			'url': 'pages/freeCall/freeCall'
		});
	},
	redirectToCarlist: function redirectToCarlist(e) {
		swan.navigateTo({
			'url': 'pages/carlist/carlist'
		});
	},
	redirectToBrandlist: function redirectToBrandlist() {
		swan.navigateTo({
			'url': 'pages/chioce-brand/chioce-brand'
		});
	},

	directClick: function directClick(e) {
		swan.navigateTo({
			'url': 'pages/direct_purchase/direct_purchase'
		});
	},
	identifyClick: function identifyClick(e) {
		swan.navigateTo({
			'url': 'pages/identify/identify'
		});
	},
	sellerCarClick: function sellerCarClick(e) {
		swan.navigateTo({
			'url': 'pages/sellCar/sellCar'
		});
	},
	orderClick: function orderClick(e) {
		swan.navigateTo({
			'url': 'pages/orderSuccess/orderSuccess'
		});
	},
	orderSeller: function orderSeller(e) {
		swan.navigateTo({
			'url': 'pages/orderSeller/orderSeller'
		});
	},
	carAccess: function carAccess(e) {
		swan.navigateTo({
			'url': 'pages/carAccess/carAccess'
		});
	},
	onePercent: function onePercent(e) {
		swan.navigateTo({
			'url': "pages/onePercent/onePercent"
		});
	},
	loadMore: function loadMore() {
		var insertItem = {
			title: '程序猿喜迎佳节，1024万人空巷，都去找三好？？？',
			imgsrc: 'https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1024874097,1179143910&fm=173&s=EF926D8DDB733282513984970300C0C2&w=218&h=146&img.JPEG',
			tags: [{
				content: '新华网',
				className: 'rn-icon-normal'
			}, {
				content: '17:44',
				className: 'rn-icon-normal'
			}]
		};
		this.dataPush('items', insertItem);
	},
	storageDel: function storageDel(e) {
		swan.navigateTo({
			url: 'pages/removeStorageMine/removeStorageMine'
		});
	},
	oneItemTouchStart: function oneItemTouchStart() {
		console.log('oneItemTouchStart');
	},

	oneItemTouchEnd: function oneItemTouchEnd() {
		console.log('oneItemTouchEnd');
	},

	onLoad: function onLoad() {
		console.log('page-init');
	},

	onReady: function onReady() {
		console.log('onReady');
	},

	onShow: function onShow() {
		console.log('onShow');
	},

	onHide: function onHide() {
		console.log('onHide');
	},

	scfunc: function scfunc() {
		console.log('scfunc');
	}
});});

/***/ }),
/* 13 */
/***/ (function(module, exports) {

PageDefine('pages/detail/detail', function (Page, getApp) {'use strict';

Page({
    data: {
        isShow: 'hide', //询底价模块是否展示，值为hide  show或者""
        autoplay: false,
        scroll: true,
        swiperCurrent: 1,
        initArr: null,
        carname: '',
        carid: '',
        pic_list: [],
        price: '',
        contrast_newcar_text: '',
        mortgage_price: '',
        month_price: '',
        is_to_move_in: '',
        cityname: '',
        mileage: '',
        regist_date_text: '',
        car_age: '',
        publish_time: '',
        discharge_lever_show: '',
        engine_type: '',
        displacement: '',
        custom_configs: [],
        quality_auth: null,
        is_show_ask_price: '',
        mobile_400: '',
        enquiryTel: '',
        mortgage: '',
        homeInfo: null,
        enquiryInfo: {},
        cityid: 201,
        carList: [],
        maxlength: 11,
        carcityid: 201
    },
    onLoad: function onLoad(option) {
        var that = this;
        var carid = option.carid || '';
        var cityid = option.cityid || '';
        swan.request({
            url: 'https://baidu.xin.com/car_detail_new/view',
            dataType: 'string',
            method: 'GET',
            header: {
                'content-type': 'application/json' // 默认值
            },
            data: {
                carid: carid,
                cityid: cityid,
                search_cityid: cityid,
                os: 'wap'
            },
            success: function success(res) {
                var initArr = res.data ? JSON.parse(res.data).data : '';
                that.setData({
                    pic_list: initArr.pic_list,
                    carname: initArr.carname,
                    carid: initArr.carid,
                    price: initArr.price,
                    contrast_newcar_text: initArr.contrast_newcar_text,
                    mortgage_price: initArr.mortgage_price,
                    month_price: initArr.month_price,
                    is_to_move_in: initArr.is_to_move_in,
                    cityname: initArr.cityname,
                    mileage: initArr.mileage,
                    regist_date_text: initArr.regist_date_text,
                    car_age: initArr.car_age,
                    publish_time: initArr.publish_time,
                    discharge_lever_show: initArr.discharge_lever_show,
                    engine_type: initArr.engine_type,
                    displacement: initArr.displacement,
                    custom_configs: initArr.custom_configs,
                    quality_auth: initArr.quality_auth,
                    is_show_ask_price: initArr.is_show_ask_price,
                    mortgage: initArr.mortgage,
                    cityid: cityid,
                    carcityid: initArr.cityid
                });
            },
            fail: function fail(err) {
                swan.showToast({
                    title: '获取数据失败'
                });
                console.log('fail');
            }
        });
        swan.request({
            url: 'https://baidu.xin.com/car_detail_new/samecar',
            dataType: 'string',
            method: 'GET',
            header: {
                'content-type': 'application/json' // 默认值
            },
            data: {
                carid: carid,
                type: 0,
                os: 'wap'
            },
            success: function success(res) {
                var carList = res.data ? JSON.parse(res.data).data : '';
                carList && this.setData({
                    carList: carList
                });
                console.log(recommendArr);
            },
            fail: function fail(err) {
                console.log('fail');
            }
        });
    },
    swiperChange: function swiperChange(e) {

        var currentNum = e.detail.current;
        currentNum += 1;
        this.setData({
            swiperCurrent: currentNum //获取当前轮播图片的下标
        });
    },
    previewImg: function previewImg(e) {
        //点击预览大图
        var bigUrls = [];
        var pic_list = this.data.pic_list;
        pic_list.forEach(function (item) {
            var urls = item.pic_src_big;
            urls && bigUrls.push(urls);
        });
        var currenturl = e.target.dataset.currenturl || '';
        swan.previewImage({
            current: currenturl,
            urls: bigUrls,
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    askPrice: function askPrice(e) {
        var _this = this;

        //询底价
        var carid = e.target.dataset.carid ? e.target.dataset.carid : this.data.carid;
        console.log(carid);
        swan.request({
            url: 'https://baidu.xin.com/b2c_enquiry/get_enquiry_times',
            dataType: 'json',
            data: {
                carid: carid
            },
            success: function success(res) {
                var enquiryInfo = res.data.data;
                _this.setData({
                    enquiryInfo: enquiryInfo
                });
            },
            fail: function fail(res) {
                console.log('fail');
            }
        });
        this.setData('isShow', 'show');
    },
    oneItemClick: function oneItemClick(e) {
        //相似推荐列表跳转详情
        var carid = e.target.dataset.carid;
        var cityid = this.data.cityid;
        swan.navigateTo({
            'url': 'pages/detail/detail?carid=' + carid + '&cityid=' + cityid
        });
    },
    closeEnquiry: function closeEnquiry(e) {
        this.setData('isShow', 'hide');
    },
    clearTel: function clearTel(e) {
        this.setData('enquiryTel', '');
    },
    bindReplaceInput: function bindReplaceInput(e) {
        var value = e.detail.value;
        this.setData({
            'value': value
        });

        //直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
        return {
            value: value.replace(/11/g, '2'),
            cursor: pos

            //或者直接返回字符串,光标在最后边
            //return value.replace(/11/g,'2'),
        };
    },
    openFanice: function openFanice(e) {
        //跳转金融页
        var carid = this.data.carid;
        var mortgage = this.data.mortgage;
        var cityid = this.data.cityid;
        swan.navigateTo({
            'url': 'pages/fanice/fanice?carid=' + carid + '&mortgage=' + mortgage + '&cityid=' + cityid
        });
    },
    openIdentify: function openIdentify(e) {
        //跳转优信认证
        swan.navigateTo({
            'url': 'pages/identify/identify'
        });
    },
    openParams: function openParams() {
        var carid = this.data.carid;
        //跳转参配
        swan.navigateTo({
            'url': 'pages/params/params?carid=' + carid
        });
    },
    openFreeCall: function openFreeCall(e) {
        //免费电话
        swan.navigateTo({
            'url': 'pages/freeCall/freeCall'
        });
    },
    openToMove: function openToMove(e) {
        //跳转到直购落地页
        var carid = this.data.carid || '';
        var carcityid = this.data.carcityid || '';
        swan.navigateTo({
            'url': 'pages/direct_purchase/direct_purchase?carid=' + carid + '&carcityid=' + carcityid
        });
    },
    'call_400': function call_400(e) {
        //拨打400电话
        var that = this;
        swan.request({
            url: 'https://baidu.xin.com/telephone/get_crm_tele',
            dataType: 'json',
            data: {
                carid: that.data.carid,
                cityid: that.data.cityid,
                os: 'wap',
                tele_source: '13'
            },
            success: function success(res) {
                var mobile_400 = res.data.data;
                that.setData({
                    mobile_400: mobile_400
                });
                console.log(mobile_400);
                swan.makePhoneCall({
                    phoneNumber: that.data.mobile_400
                });
            },
            fail: function fail(res) {
                console.log('fail');
                showToast({
                    title: '获取电话失败'
                });
            }
        });
    },
    enquiryClick: function enquiryClick(e) {
        //询底价弹窗的询底价按钮
        console.log(this.data.enquiryTel);
        var that = this;
        var enquiryTel = this.data.enquiryTel;
        if (!enquiryTel) {
            swan.showToast({
                title: '请输入您的手机号码'
            });
            return;
        }
        if (!/^1[3|4|5|8][0-9]\d{4,8}$/.test(enquiryTel)) {
            swan.showToast({
                title: '请输入正确的手机号码'
            });
            return false;
        }
        swan.request({
            url: 'https://baidu.xin.com/b2c_enquiry/save',
            dataType: 'json',
            data: {
                carid: that.data.carid,
                cityid: that.data.cityid,
                seriesid: that.data.seriesid,
                mobile: that.data.enquiryTel
            },
            success: function success(res) {
                swan.showToast({
                    title: '我们将以短信或电话的方式告知您此车的价格，敬请留意！'
                });
                that.setData('isShow', 'hide');
            },
            fail: function fail(res) {
                console.log('fail');
                swan.showToast({
                    title: '提交电话号码失败'
                });
            }
        });
    }
});});

/***/ }),
/* 14 */
/***/ (function(module, exports) {

PageDefine('pages/api/api', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */

/* eslint-disable */

Page({
    data: {
        items: [{
            cortName: '位置',
            cortList: [{
                subName: '获取位置',
                subList: [{
                    id: 'getLocation'
                }]
            }]
        }, {
            cortName: '开放接口',
            cortList: [{
                subName: '授权',
                subList: [{
                    id: 'authorize'
                }]
            }, {
                subName: '登录',
                subList: [{
                    id: 'login'
                }, {
                    id: 'checkSession'
                }]
            }, {
                subName: '用户信息',
                subList: [{
                    id: 'getUserInfo'
                }]
            }, {
                subName: '支付',
                subList: [{
                    id: 'requestPayment'
                }, {
                    id: 'requestAliPayment'
                }]
            }, {
                subName: '设置',
                subList: [{
                    id: 'getSetting'
                }, {
                    id: 'openSetting'
                }]
            }, {
                subName: '分享',
                subList: [{
                    id: 'openShare'
                }]
            }]
        }, {
            cortName: '界面',
            cortList: [{
                subName: '交互反馈',
                subList: [{
                    id: 'showActionSheet'
                }, {
                    id: 'showModal'
                }, {
                    id: 'showToast'
                }, {
                    id: 'showLoading'
                }]
            }, {
                subName: '导航',
                subList: [{
                    id: 'navigateTo'
                }, {
                    id: 'redirectTo'
                }, {
                    id: 'switchTab'
                }, {
                    id: 'navigateBack'
                }, {
                    id: 'reLaunch'
                }, {
                    id: 'webView'
                }]
            }, {
                subName: '设置导航条',
                subList: [{
                    id: 'setNavigationBarColor'
                }, {
                    id: 'setNavigationBarTitle'
                }, {
                    id: 'showNavigationBarLoading'
                }]
            }, {
                subName: '下拉刷新',
                subList: [{
                    id: 'startPullDownRefresh'
                }]
            }]
        }, {
            cortName: '设备',
            cortList: [{
                subName: '系统信息',
                subList: [{
                    id: 'getSystemInfo'
                }, {
                    id: 'getSystemInfoSync'
                }]
            }, {
                subName: '网络状态',
                subList: [{
                    id: 'getNetworkType'
                }]
            }, {
                subName: '拨打电话',
                subList: [{
                    id: 'makePhoneCall'
                }]
            }, {
                subName: '剪贴板',
                subList: [{
                    id: 'setClipboardData'
                }]
            }]
        }, {
            cortName: '媒体',
            cortList: [{
                subName: '图片',
                subList: [{
                    id: 'previewImage'
                }]
            }]
        }, {
            cortName: '网络',
            cortList: [{
                subName: '发起请求',
                subList: [{
                    id: 'request'
                }]
            }]
        }],
        noSubapi: [{
            cortName: '数据缓存',
            cortList: [{
                id: 'getStorage'
            }, {
                id: 'getStorageSync'
            }, {
                id: 'getStorageInfo'
            }, {
                id: 'getStorageInfoSync'
            }, {
                id: 'setStorage'
            }, {
                id: 'setStorageSync'
            }, {
                id: 'removeStorage'
            }, {
                id: 'removeStorageSync'
            }, {
                id: 'clearStorage'
            }, {
                id: 'clearStorageSync'
            }]
        }]
    },

    oneItemClick: function oneItemClick(e) {
        var apiName = e.target.dataset.id;
        swan.navigateTo({
            url: 'pages/' + apiName + '/' + apiName
        });
    },
    toggleClick: function toggleClick(e) {}
});});

/***/ }),
/* 15 */
/***/ (function(module, exports) {

PageDefine('pages/getNetworkType/getNetworkType', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getNetworkType'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getNetworkType({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log(JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 16 */
/***/ (function(module, exports) {

PageDefine('pages/showNavigationBarLoading/showNavigationBarLoading', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'showNavigationBarLoading'
        },
        item2: {
            id: 'hideNavigationBarLoading'
        }
    },

    showClick: function showClick() {
        window.swan.showNavigationBarLoading();
    },

    hideClick: function hideClick() {
        window.swan.hideNavigationBarLoading();
    }
});});

/***/ }),
/* 17 */
/***/ (function(module, exports) {

PageDefine('pages/setClipboardData/setClipboardData', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'setClipboardData'
        },
        item2: {
            id: 'getClipboardData'
        }
    },

    setClipboardData: function setClipboardData() {
        window.swan.setClipboardData({
            data: 'baidu',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    getClipboardData: function getClipboardData() {
        window.swan.getClipboardData({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 18 */
/***/ (function(module, exports) {

PageDefine('pages/getSystemInfo/getSystemInfo', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSystemInfo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getSystemInfo({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 19 */
/***/ (function(module, exports) {

PageDefine('pages/getSystemInfoSync/getSystemInfoSync', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSystemInfoSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getSystemInfoSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('getSystemInfoSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 20 */
/***/ (function(module, exports) {

PageDefine('pages/makePhoneCall/makePhoneCall', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'makePhoneCall'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.makePhoneCall({
            phoneNumber: '1234567890'
        });
    }
});});

/***/ }),
/* 21 */
/***/ (function(module, exports) {

PageDefine('pages/navigateBack/navigateBack', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'navigateBack'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.navigateBack({
            delta: 1,
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 22 */
/***/ (function(module, exports) {

PageDefine('pages/navigateTo/navigateTo', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'navigateTo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.navigateTo({
            url: 'pages/navigateTo/navigateTo',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 23 */
/***/ (function(module, exports) {

PageDefine('pages/redirectTo/redirectTo', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'redirectTo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.redirectTo({
            url: 'pages/detail/detail?key=value',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 24 */
/***/ (function(module, exports) {

PageDefine('pages/reLaunch/reLaunch', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'reLaunch'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.reLaunch({
            url: 'pages/api/api',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 25 */
/***/ (function(module, exports) {

PageDefine('pages/setNavigationBarColor/setNavigationBarColor', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setNavigationBarColor'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.setNavigationBarColor({
            frontColor: '#ffffff',
            backgroundColor: '#0099cc',
            animation: {
                duration: 500,
                timingFunc: 'easeIn'
            },
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 26 */
/***/ (function(module, exports) {

PageDefine('pages/showModal/showModal', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'showModal'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.showModal({
            title: 'wowowo',
            content: '提示的内容',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 27 */
/***/ (function(module, exports) {

PageDefine('pages/showActionSheet/showActionSheet', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'showActionSheet'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.showActionSheet({
            itemList: ['我', '是', '谁'],
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 28 */
/***/ (function(module, exports) {

PageDefine('pages/switchTab/switchTab', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'switchTab'
        }
    },

    oneItemClick: function oneItemClick() {
        console.log('switchtabClick');
        window.swan.switchTab({
            url: 'pages/index/index',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 29 */
/***/ (function(module, exports) {

PageDefine('pages/setNavigationBarTitle/setNavigationBarTitle', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setNavigationBarTitle'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.setNavigationBarTitle({
            title: '我是标题',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 30 */
/***/ (function(module, exports) {

PageDefine('pages/setStorage/setStorage', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.setStorage({
            key: 'rzh',
            data: '111',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 31 */
/***/ (function(module, exports) {

PageDefine('pages/setStorageSync/setStorageSync', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'setStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.setStorageSync('rzh', '1234');
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('setStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 32 */
/***/ (function(module, exports) {

PageDefine('pages/getStorage/getStorage', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getStorage({
            key: 'rzh',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 33 */
/***/ (function(module, exports) {

PageDefine('pages/getStorageSync/getStorageSync', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getStorageSync('rzh');
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('getStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 34 */
/***/ (function(module, exports) {

PageDefine('pages/getStorageInfo/getStorageInfo', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorageInfo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getStorageInfo({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 35 */
/***/ (function(module, exports) {

PageDefine('pages/getStorageInfoSync/getStorageInfoSync', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getStorageInfoSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.getStorageInfoSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('getStorageInfoSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 36 */
/***/ (function(module, exports) {

PageDefine('pages/removeStorage/removeStorage', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'removeStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.removeStorage({
            key: 'rzh',
            success: function success(res) {
                window.swan.showToast({
                    title: '删除返回结果:::' + JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 37 */
/***/ (function(module, exports) {

PageDefine('pages/removeStorageSync/removeStorageSync', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'removeStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.removeStorageSync('rzh');
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('removeStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 38 */
/***/ (function(module, exports) {

PageDefine('pages/clearStorage/clearStorage', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'clearStorage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.clearStorage();
    }
});});

/***/ }),
/* 39 */
/***/ (function(module, exports) {

PageDefine('pages/clearStorageSync/clearStorageSync', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'clearStorageSync'
        }
    },

    oneItemClick: function oneItemClick() {
        var result = window.swan.clearStorageSync();
        window.swan.showToast({
            title: JSON.stringify(result)
        });
        console.log('clearStorageSync::' + JSON.stringify(result));
    }
});});

/***/ }),
/* 40 */
/***/ (function(module, exports) {

PageDefine('pages/request/request', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'request'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.request({
            url: 'https://14592619.qcloud.la/testRequest',
            dataType: 'json',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 41 */
/***/ (function(module, exports) {

PageDefine('pages/previewImage/previewImage', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'previewImage'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.previewImage({
            urls: ['https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1844830708,4171352519&fm=173&s=72E225E004EA85551C46C48C0300F0CB&w=600&h=337&img.JPEG', 'https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1844830708,4171352519&fm=173&s=72E225E004EA85551C46C48C0300F0CB&w=600&h=337&img.JPEG'],
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 42 */
/***/ (function(module, exports) {

PageDefine('pages/showToast/showToast', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'showToast'
        },
        item2: {
            id: 'hideToast'
        }
    },

    showClick: function showClick() {
        window.swan.showToast({
            duration: 5000,
            title: 'showToast',
            icon: 'success'
        });
    },

    hideClick: function hideClick() {
        window.swan.hideToast();
    }
});});

/***/ }),
/* 43 */
/***/ (function(module, exports) {

PageDefine('pages/showLoading/showLoading', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'showLoading'
        },
        item2: {
            id: 'hideLoading'
        }
    },

    showClick: function showClick() {
        window.swan.showLoading({
            title: 'loading'
        });
    },

    hideClick: function hideClick() {
        window.swan.hideLoading();
    }
});});

/***/ }),
/* 44 */
/***/ (function(module, exports) {

PageDefine('pages/startPullDownRefresh/startPullDownRefresh', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'startPullDownRefresh'
        },
        item2: {
            id: 'stopPullDownRefresh'
        }
    },

    showClick: function showClick() {
        window.swan.startPullDownRefresh();
    },

    hideClick: function hideClick() {
        window.swan.stopPullDownRefresh();
    }
});});

/***/ }),
/* 45 */
/***/ (function(module, exports) {

PageDefine('pages/authorize/authorize', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items1: {
            id: 'authorize-userInfo'
        },
        item2: {
            id: 'authorize-userLocation'
        },
        item3: {
            id: 'authorize-mobile'
        }
    },

    auserInfo: function auserInfo() {
        window.swan.authorize({
            scope: 'scope.userInfo',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    auserLocation: function auserLocation() {
        window.swan.authorize({
            scope: 'scope.userLocation',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    amobile: function amobile() {
        window.swan.authorize({
            scope: 'scope.mobile',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                window.swan.showToast({
                    title: JSON.stringify(err)
                });
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 46 */
/***/ (function(module, exports) {

PageDefine('pages/getLocation/getLocation', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getLocation'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getLocation({
            type: 'wgs84',
            altitude: true,
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 47 */
/***/ (function(module, exports) {

PageDefine('pages/checkSession/checkSession', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'checkSession'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.checkSession({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 48 */
/***/ (function(module, exports) {

PageDefine('pages/getUserInfo/getUserInfo', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getUserInfo'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getUserInfo({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 49 */
/***/ (function(module, exports) {

PageDefine('pages/getSetting/getSetting', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'getSetting'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.getSetting({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 50 */
/***/ (function(module, exports) {

PageDefine('pages/openSetting/openSetting', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'openSetting'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.openSetting({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 51 */
/***/ (function(module, exports) {

PageDefine('pages/login/login', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'login'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.login({
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 52 */
/***/ (function(module, exports) {

PageDefine('pages/requestPayment/requestPayment', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'requestPayment'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.requestPayment({
            orderinfo: {
                'goods_name': encodeURIComponent(document.getElementById('goods_name').value),
                'total_amount': document.getElementById('total_amount').value,
                'sp_no': document.getElementById('sp_no').value,
                'return_url': encodeURIComponent(document.getElementById('return_url').value),
                debug: true,
                'order_create_time': document.getElementById('order_create_time').value,
                'order_no': document.getElementById('order_no').value,
                'goods_desc': document.getElementById('goods_desc').value,
                currency: '1',
                'input_charset': '1',
                sign: document.getElementById('sign').value,
                'sign_method': '1'
            },
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 53 */
/***/ (function(module, exports) {

PageDefine('pages/requestAliPayment/requestAliPayment', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        items: {
            id: 'requestAliPayment'
        }
    },

    oneItemClick: function oneItemClick() {
        window.swan.requestAliPayment({
            orderinfo: '1234',
            success: function success(res) {
                window.swan.showToast({
                    title: JSON.stringify(res)
                });
                console.log(JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 54 */
/***/ (function(module, exports) {

PageDefine('pages/openShare/openShare', function (Page, getApp) {'use strict';

/**
 * @file demo page for apiDemo
 * @author renzhonghua@baidu.com
 */
Page({
    data: {
        item1: {
            id: 'openShare'
        }
    },

    addClick: function addClick() {
        document.addEventListener('sharebtn', function (e) {
            console.log('sharebtn');
            var url = 'https://po.baidu.com/act/tpl/index.html?t=guideapp&type=scheme&from=&channel=&iosScheme';
            var scheme = 'baiduboxapp://v18/swan/launch?appid=1';

            window.swan.openShare({
                mediaType: 'all',
                title: '小程序标题',
                content: '世界很复杂，百度更懂你',
                iconUrl: 'http://imgsrc.baidu.com/forum/pic/item/d9f9d72a6059252daecdfc36309b033b5bb5b92e.jpg',
                linkUrl: url + scheme + '&andCommand' + scheme,
                pannel: ['sinaweibo', 'weixin_friend', 'baiduhi'],
                type: 'url',
                path: '/pages/openShare/openShare',
                success: function success(res) {
                    window.swan.showToast({
                        title: JSON.stringify(res)
                    });
                    console.log(JSON.stringify(res));
                },
                fail: function fail(err) {
                    console.log(JSON.stringify(err));
                }
            });
        }, false);
    }
});});

/***/ }),
/* 55 */
/***/ (function(module, exports) {

PageDefine('pages/main/main', function (Page, getApp) {'use strict';

//app入口 帮助排错

Page({
  initData: {
    str: 'hello baidubox app'
  },
  redirectTo: function redirectTo(e) {
    swan.navigateTo({
      'url': 'pages/home/home'
    });
  },
  redirectToCarlist: function redirectToCarlist(e) {
    swan.navigateTo({
      'url': 'pages/carlist/carlist'
    });
  }
});});

/***/ }),
/* 56 */
/***/ (function(module, exports) {

PageDefine('pages/home/home', function (Page, getApp) {'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//跳转页面
var navigateTo = function navigateTo(opt) {
    swan.navigateTo(opt);
};
Page({
    data: _defineProperty({
        dots: false,
        ajaxparams: {},
        //主页上半部分的数据
        homeInfo: null,
        //猜你喜欢
        loveCars: {},
        //热门推荐
        hotReCommend: {},
        //猜你喜欢控制参数
        HaveThree: true,
        NoHaveThree: false,
        city: { cityid: 201, cityname: "北京" },
        initParams: {
            cityid: 201, //int	是	定位或者用户选择的城市单个城市ID，如201
            search_cityid: 201, //	string	是	搜索城市id，区域时传递多个城市ID组成的字符串,201,2601,901；单个城市时同cityid字段
            offset: 0, //int	是	首次传0，后面接收服务端返回下次请求带过来即可。（只需要传递过来即可，不需要任何计算）
            only_local: 0, //	int	是	只加载本地车源 开关 ，1：只加载本地车源、0：本地+直购车源 ，不传默认是0
            keyword: '', //	str	否	搜索关键词
            query: '', //	str	否	suggest词（搜索框）
            brandid: 0, //	int	否	品牌 0或空为不筛选此条件
            serieid: 0, //int	否	车系 0或空为不筛选此条件，多车系传递类似后面的格式 ，1993_449_382_391
            modelid: 0, //	int	否	车型 0或空为不筛选此条件 有车型的时候品牌和车系条件无效
            caridhiddenlist: '', //	str	否	不显示的车id列表，多个车id用英文逗号,分割，caridhiddenlist中的车将不显示在列表中
            category: 0, //	int	否	车型分类 0或空为不筛选此条件 数字时为车型的分类，suv，小型车，中型车等
            pricemin: 0, //	int	否	车辆价格筛选最小值 空为不筛选此条件，0为大于等于0元
            pricemax: 0, //int	否	车辆价格筛选最大值 空为不筛选此条件，为数字n的时候意味着价格小于等于n万元
            agemin: 0, //	int	否	车龄筛选最小值（0,1,2,3 这种数值）
            agemax: 0, //	int	否	车龄筛选最大值（0,1,2,3 这种数值） 0或空为不筛选此条件(如5年以上的时候此值可为空或数字0，只传最小值agemin=5 即可）
            mileagemin: 0, //	int	否	行驶里程筛选最小值 空为不筛选此条件，0为大于等于0万公里
            mileagemax: 0, //	int	否	行驶里程筛选最大值 空为不筛选此条件，为数字n的时候意味着行驶里程小于等于n万公里
            gearbox: 0, //	int	否	变速箱类型 0或空为不筛选此条件 数字时为变速箱的类型，自动，手动等
            fueltype: 0, //	int	否	燃料类别（0不限，1汽油、2柴油、3纯电动、4油电混合）
            seatnum: 0, //int	否	座位数（0-不限，2-2座，4-4座，5-5座，7-7座,8-7座以上）
            displacementmin: 0, //	float	否	排量筛选最小值 空为不筛选此条件，0为大于等于0L
            displacementmax: 0, //	float	否	排量筛选最大值 空为不筛选此条件，为数字n的时候意味着小于等于nL
            color: 0, //	int	否	车辆颜色 0或空为不筛选此条件
            country: 0, //	int	否	产地 0或空为不筛选此条件 数字时为国别，自主。合资，进口等
            mortgage: 0, //int	否	半价车 1半价车 -1为非半价车，0、空：全价车 2:半价车+全价车
            orderprice: 0, //	int	否	价格排序：0或null排序不使用价格； 1从小到大； 2从大到小
            orderage: 0, //int	否	车龄排序：0或null排序不使用价格；1从新到旧；2从旧到新
            ordermileage: 0, //	int	否	里程排序：0或null排序不使用里程；1从小到大； 2从大到小
            onlycount: 0, //	int	否	1为只返回总数/ 默认值0
            onlyperson: 0, //	int	否	只返回个人车源：1只返回个人车源
            quality_query_type: 0, //	int	否	车源类型： 0：全部车源；1：无事故承诺； 5：优信认证；6：付一成
            distance_asc: 0, //int	否	1：距离最近
            country_type: 0, //int	否	国别（不限、德系、日系、韩系、美系、法系、国产、非国产、非日系 分别用 0- 8 的数字表示）
            longitude: '', //	string	否	地理位置 -经度
            latitude: '', //	string	否	地理位置 -纬度
            os: 'wap',
            n_p: '', //页码）,c_p（页码）,multi_mode_word（分词）,
            zg_num: '' //（页码）,loc_num（页码）int	否 	 接口返回，客户端接收到直接带回即可，不需要处理逻辑
        },
        pageChange: true
    }, 'city', { cityid: 1, cityname: '全国' }),
    onLoad: function onLoad() {
        //页面加载完成
        var that = this;
        swan.request({ //1.获取主页上半部分的数据
            url: 'https://baidu.xin.com/home/config_item',
            data: { cityid: 201 },
            success: function success(res) {
                var finalResOne = res.data;
                that.setData('homeInfo', finalResOne.data);
                if (homeInfo.banner_list.length > 1) {
                    this.setData('dots', true);
                }
            },
            fali: function fali(res) {
                console.log("请求失败" + res);
            }
        });
        swan.request({ //2.获取热门推荐的数据
            url: 'https://baidu.xin.com/home/hot_recommend',
            success: function success(res) {
                var finalResTwo = res.data;
                that.setData('hotReCommend', finalResTwo.data);
            },
            fali: function fali(res) {
                console.log("请求失败" + res);
            }
        });
        swan.getLocation({
            type: 'gcj02',
            success: function success(res) {
                console.log(res.latitude);
                console.log(res.longitude);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    getYouLoveList: function getYouLoveList() {
        var that = this;
        swan.request({ //3.获取猜你喜欢的数据
            url: 'https://baidu.xin.com/home/guess_your_like',
            data: { cityid: this.data.city.cityid },
            success: function success(res) {
                console.log("请求成功");

                var finalResThree = res.data;
                if (finalResThree.data.list.length < 3) {
                    that.setData({ HaveThree: false, NoHaveThree: true });
                } else {
                    that.setData({ HaveThree: true, NoHaveThree: false });
                }
                that.setData('loveCars', finalResThree.data);
            },
            fali: function fali(res) {
                console.log("请求失败" + res);
            }
        });
    },
    onShow: function onShow(e) {
        var that = this;
        swan.getStorage({ //取出
            // 数据params
            key: 'city',
            success: function success(res) {
                console.log(res.data);
                that.setData({
                    city: res.data
                });
                that.data.initParams.cityid = res.data.cityid;
                that.getYouLoveList();
            },
            fail: function fail(res) {
                console.log("获取数据失败" + res);
                var city = { cityid: 1, cityname: '全国' };
                that.setData({
                    city: city
                });
            }
        });
    },
    alreadyToCarList: function alreadyToCarList(Params) {
        Params.cityname = this.data.city.cityname;
        swan.removeStorage({
            key: 'ajaxparams',
            success: function success() {
                swan.setStorage({
                    key: 'ajaxparams',
                    data: Params,
                    success: function success(res) {
                        swan.switchTab({
                            url: 'pages/carlist/carlist',
                            success: function success(res) {
                                console.log(res);
                            },
                            fails: function fails(res) {
                                console.log(res);
                            }
                        });
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            }
        });
    },
    //导航跳转页面
    navigateEvent: function navigateEvent(e) {
        console.log("初始化数据：：：");
        console.log(this.data.initParams);
        switch (e.target.dataset.navigateType) {
            case 1:
                //type为1(买车) 跳转到全价车列表页
                var storageParams = {};
                storageParams.cityid = this.data.initParams.cityid;
                this.alreadyToCarList(storageParams);
                break;
            case 2:
                //跳转到一成购列表页
                var qualityParams = {};
                qualityParams.quality_query_type = 6;
                qualityParams.cityid = this.data.initParams.cityid;
                this.alreadyToCarList(qualityParams);

                break;
            case 3:
                //跳转到分期购列表页
                this.onSellCarList();
                break;
            case 4:
                //跳转到C2B卖车页
                swan.switchTab({
                    url: 'pages/sellCar/sellCar'
                });
                break;
            case 5:
                //type为5(估价) 跳转到估价提交资料页
                navigateTo({
                    url: 'pages/orderSeller/orderSeller'
                });
                break;
        }
    },
    //优信认证和一成购跳转页面
    onIdAndCut: function onIdAndCut(e) {
        switch (e.target.dataset.idType) {
            case 1:
                navigateTo({
                    url: 'pages/identify/identify'
                });
                break;
            case 2:
                navigateTo({
                    url: 'pages/onePercent/onePercent'
                });
                break;
        }
    },
    //预约卖车
    onBespeak: function onBespeak() {
        navigateTo({
            url: 'pages/bespeak/bespeak'
        });
    },
    //先估价
    onGoEvaluation: function onGoEvaluation() {
        navigateTo({
            url: 'pages/evaluatioin/evaluatioin'
        });
    },
    //点击切换城市
    onChioseCity: function onChioseCity() {
        navigateTo({
            url: 'pages/chioce-city/chioce-city?chooseType=home'
        });
    },
    //点击去搜索页面
    onSearch: function onSearch() {
        navigateTo({
            url: 'pages/search/search'
        });
    },
    //去列表页判断
    onClickToCarList: function onClickToCarList(e) {
        var that = this;
        this.data.ajaxparams = {};
        this.data.ajaxparams.cityid = Number(this.data.city.cityid);
        this.data.ajaxparams.cityname = this.data.city.cityname;
        switch (e.target.dataset.jumpType) {//判断跳转类型
            case '1':
                this.data.ajaxparams.pricemin = e.target.dataset.priceMin;
                this.data.ajaxparams.pricemax = e.target.dataset.priceMax;
                this.data.ajaxparams.pricename = e.target.dataset.priceName;
                break;
            case '2':
                switch (e.target.dataset.carCategory) {
                    case 1:
                        this.data.ajaxparams.category = '1_2_3';
                        break;
                    case 2:
                        this.data.ajaxparams.pricemax = 15;
                        this.data.ajaxparams.category = 8;
                        break;
                    case 3:
                        this.data.ajaxparams.agemax = 2;
                        this.data.ajaxparams.mileagemax = 3;
                        break;
                    case 4:
                        this.data.ajaxparams.pricemax = 5;
                        break;
                }
                console.log(this.data.ajaxparams);
                break;
            case '3':
                this.data.ajaxparams.brandid = e.target.dataset.brandId;
                this.data.ajaxparams.brandname = e.target.dataset.brandname;
                break;
            case '4':
                this.data.ajaxparams = {};
                break;
            case '5':
                this.data.ajaxparams = e.target.dataset.params;
                break;
        }
        window.swan.removeStorage({
            key: 'ajaxparams',
            success: function success(res) {
                console.log('removeStorage success');
                that.setParams();
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },

    setParams: function setParams() {
        var that = this;
        swan.setStorage({
            key: 'ajaxparams',
            data: that.data.ajaxparams,
            success: function success(res) {
                console.log(that.data.ajaxparams);
                that.onSellCarList();
            }
        });
    },

    onSellCarList: function onSellCarList() {
        swan.switchTab({
            url: 'pages/carlist/carlist',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    onDetail: function onDetail(e) {
        //去详情页
        swan.navigateTo({
            url: 'pages/detail/detail?carid=' + e.target.dataset.carId + "&seriesid=" + e.target.dataset.seriesId + "&cityid=" + this.data.city.cityid,
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    //预约卖车
    onClickToYySeller: function onClickToYySeller() {
        navigateTo({
            url: 'pages/orderSeller/orderSeller'
        });
    }
});});

/***/ }),
/* 57 */
/***/ (function(module, exports) {

PageDefine('pages/params/params', function (Page, getApp) {'use strict';

Page({
    data: {
        ShowTxt: '',
        params: null
        //ResName:[]
    },
    onLoad: function onLoad(option) {
        var carid = option.carid;
        var that = this;
        swan.request({
            url: 'https://baidu.xin.com/car_mode/mode_dict_list',
            dataType: 'json',
            data: {
                carid: carid
            },
            success: function success(res) {
                var FinalRes = res.data.data;
                that.setData('params', FinalRes);
                console.log(that.data.params);

                // var FinalRes = JSON.parse(res.data).data
                // console.log(FinalRes)
                // var Name= [];
                // for(var i = 0 ; i < FinalRes.length ; i ++){
                //     if(Name.indexOf(FinalRes[i].pcname)==-1){
                //         Name.push(FinalRes[i].pcname)
                //     }
                // };
                // that.setData('ResName',Name)
                // console.log(that.data.ResName)
                // var Linshi = [];
                // for(var j = 0 ; j < that.data.ResName.length ; j ++){
                //     for(var k =  0; k < FinalRes.length ; k++){
                //         if(FinalRes[k].pcname == that.data.ResName[j]){
                //             Linshi.push(FinalRes[k])
                //             that.data.params[that.data.ResName[j]]=Linshi
                //         }
                //     }
                // }
                // that.setData('params',that.data.params)
                // console.log(that.data.params)
            },
            fali: function fali(res) {
                console.log("请求失败" + res.data.data);
            }
        });
    }

});});

/***/ }),
/* 58 */
/***/ (function(module, exports) {

PageDefine('pages/search/search', function (Page, getApp) {'use strict';

//搜索页面
Page({
    data: {
        suggestMsg: [],
        isShow: 1,
        ajaxparams: {},
        History: [],
        Hot: [{ car: '3万买豪车', param: { pricemax: 3 } }, { car: '大众', param: { brandid: 84 } }, { car: '奔驰', param: { brandid: 47 } }, { car: '宝马', param: { brandid: 38 } }, { car: '奥迪', param: { brandid: 62 } }, { car: '丰田', param: { brandid: 89 } }, { car: '超值SUV', param: { pricemax: 15, category: 8 } }, { car: '准新车', param: { agemax: 2, mileagemax: 3 } }, { car: '千元月供好车', param: {
                serieid: '621_269_2728_2487_3546_422_3291_3014_2705_143_664_246_532_2011_1087_2671_997_3060_1006_1950',
                pricemin: 5,
                pricemax: 15,
                mortgage: 1
            } }, { car: '5万以内', param: { pricemax: 5 } }, { car: '5-8万', param: { pricemin: 5, pricemax: 8 } }]

    },
    onHome: function onHome() {
        swan.switchTab({
            url: 'pages/home/home'
        });
    },
    toSearchHot: function toSearchHot(e) {
        console.log(e.target.dataset.searchParam);
        swan.setStorage({
            key: 'ajaxparams',
            data: e.target.dataset.searchParam,
            success: function success(res) {
                swan.switchTab({
                    url: 'pages/carlist/carlist',
                    success: function success(res) {
                        console.log(res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            },
            fail: function fail(res) {
                console.log("setFail");
            }

        });
    },
    GoCarList: function GoCarList(e) {
        for (var i = 0; i < this.data.History.length; i++) {
            if (this.data.History[i].query == e.target.dataset.query) {
                this.data.History.splice(i, 1);
            }
        }
        this.data.History.unshift({ carname: e.target.dataset.keyword, query: e.target.dataset.query });
        swan.setStorage({
            key: 'History',
            data: this.data.History
        });

        this.data.ajaxparams.query = e.target.dataset.query;
        swan.setStorage({
            key: 'ajaxparams',
            data: this.data.ajaxparams,
            success: function success() {
                swan.switchTab({
                    url: 'pages/carlist/carlist',
                    success: function success(res) {
                        console.log(res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            }
        });
    },
    changeValue: function changeValue(e) {
        //input里输入 获取suggest词
        console.log(e);
        if (e.detail.value != "") {
            this.setData('isShow', 2);
        } else {
            this.setData('isShow', 1);
        }
        console.log(this.data.isShow);
        var that = this;
        swan.request({
            url: 'https://baidu.xin.com/search/tip/',
            dataType: 'json',
            data: {
                cityid: 201,
                keyword: e.detail.value + ''
            },
            success: function success(res) {
                //console.log(JSON.parse(res.data))
                that.data.suggestMsg = res.data.data;
                that.setData('suggestMsg', that.data.suggestMsg);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    cleanTip: function cleanTip() {
        var that = this;
        swan.setStorage({
            key: 'History',
            data: '[]',
            success: function success() {
                that.setData('History', []);
            }
        });
    },
    onShow: function onShow() {
        var that = this;
        swan.getStorage({
            key: 'History',
            success: function success(res) {
                console.log("这是取出的本地数据");
                console.log(res.data);
                that.setData('History', res.data);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }

});});

/***/ }),
/* 59 */
/***/ (function(module, exports) {

PageDefine('pages/appoint/appoint', function (Page, getApp) {"use strict";

Page({
    initData: {},
    onLoad: function onLoad() {}
});});

/***/ }),
/* 60 */
/***/ (function(module, exports) {

PageDefine('pages/fanice/fanice', function (Page, getApp) {'use strict';

Page({
    data: {
        financialplan: null,
        PlanOne: [],
        PlanThree: [],
        PlanFive: [],
        TotalRes: null,
        isShow: 1,
        carid: '',
        cityid: ''
    },
    changeColor: function changeColor(e) {
        this.setData('isShow', e.target.dataset.colorNum);
    },
    call400: function call400() {
        var _this = this;

        var that = this;
        swan.request({
            url: 'https://baidu.xin.com/telephone/get_crm_tele',
            dataType: 'json',
            data: {
                carid: that.data.carid,
                cityid: that.data.cityid,
                os: 'wap',
                tele_source: '13'
            },
            success: function success(res) {
                var mobile_400 = res.data.data;
                _this.setData({
                    mobile_400: mobile_400
                });
                console.log(mobile_400);
                swan.makePhoneCall({
                    phoneNumber: _this.data.mobile_400
                });
            },
            fail: function fail(res) {
                console.log('fail');
                showToast({
                    title: '获取电话失败'
                });
            }
        });
    },
    onLoad: function onLoad(option) {
        var that = this;
        this.setData('carid', option.carid);
        this.setData('cityid', option.cityid);
        console.log(option);
        swan.request({
            url: 'https://baidu.xin.com/wap/financialplan/wap_jrfa',
            dataType: 'json',
            data: {
                carid: option.carid,
                mortgage: option.mortgage
            },
            success: function success(res) {
                var FinalRes = res.data.data;
                that.setData('financialplan', FinalRes);
                for (var i = 0; i < that.data.financialplan.schemes.length; i++) {
                    if (that.data.financialplan.schemes[i].title == 1) {
                        that.data.PlanOne.push(that.data.financialplan.schemes[i]);
                        that.setData('PlanOne', that.data.PlanOne);
                    } else if (that.data.financialplan.schemes[i].title == 3) {
                        that.data.PlanThree.push(that.data.financialplan.schemes[i]);
                        that.setData('PlanThree', that.data.PlanThree);
                    } else {
                        that.data.PlanFive.push(that.data.financialplan.schemes[i]);
                        that.setData('PlanFive', that.data.PlanFive);
                    }
                }

                if (that.data.PlanOne.length == 0) {
                    that.setData('TotalRes', [{ a: that.data.PlanThree }, { a: that.data.PlanFive }]);
                } else if (that.data.PlanThree.length == 0) {
                    that.setData('TotalRes', [{ a: that.data.PlanOne }, { a: that.data.PlanFive }]);
                } else if (that.data.PlanFive.length == 0) {
                    that.setData('TotalRes', [{ a: that.data.PlanOne }, { a: that.data.PlanThree }]);
                } else {
                    that.setData('TotalRes', [{ a: that.data.PlanOne }, { a: that.data.PlanThree }, { a: that.data.PlanFive }]);
                }
                that.setData('isShow', that.data.TotalRes[0].a[0].title);
                console.log(that.data.TotalRes);
                for (var m = 0; m < that.data.TotalRes.length; m++) {
                    for (var n = 0; n < that.data.TotalRes[m].a.length; n++) {
                        that.data.TotalRes[m].a[n].monthly_payment = Math.round(that.data.TotalRes[m].a[n].monthly_payment);
                    }
                }
                that.setData('TotalRes', that.data.TotalRes);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }
});});

/***/ }),
/* 61 */
/***/ (function(module, exports) {

PageDefine('pages/carlist/carlist', function (Page, getApp) {'use strict';

Page({
    data: {
        ajaxhost: "https://baidu.xin.com",
        isAbleRequest: true,
        allCar: true,
        halfCar: false,
        loadMoreText: '正在加载',
        isHideLoadMore: false,
        total: 0,
        ajaxParams: {
            cityid: 201, //int	是	定位或者用户选择的城市单个城市ID，如201
            offset: 0, //int	是	首次传0，后面接收服务端返回下次请求带过来即可。（只需要传递过来即可，不需要任何计算）
            only_local: 0, //	int	是	只加载本地车源 开关 ，1：只加载本地车源、0：本地+直购车源 ，不传默认是0
            keyword: '', //	str	否	搜索关键词
            query: '', //	str	否	suggest词（搜索框）
            brandid: 0, //	int	否	品牌 0或空为不筛选此条件
            serieid: 0, //int	否	车系 0或空为不筛选此条件，多车系传递类似后面的格式 ，1993_449_382_391
            modelid: 0, //	int	否	车型 0或空为不筛选此条件 有车型的时候品牌和车系条件无效
            caridhiddenlist: '', //	str	否	不显示的车id列表，多个车id用英文逗号,分割，caridhiddenlist中的车将不显示在列表中
            category: 0, //	int	否	车型分类 0或空为不筛选此条件 数字时为车型的分类，suv，小型车，中型车等
            pricemin: 0, //	int	否	车辆价格筛选最小值 空为不筛选此条件，0为大于等于0元
            pricemax: 0, //int	否	车辆价格筛选最大值 空为不筛选此条件，为数字n的时候意味着价格小于等于n万元
            agemin: 0, //	int	否	车龄筛选最小值（0,1,2,3 这种数值）
            agemax: 0, //	int	否	车龄筛选最大值（0,1,2,3 这种数值） 0或空为不筛选此条件(如5年以上的时候此值可为空或数字0，只传最小值agemin=5 即可）
            mileagemin: 0, //	int	否	行驶里程筛选最小值 空为不筛选此条件，0为大于等于0万公里
            mileagemax: 0, //	int	否	行驶里程筛选最大值 空为不筛选此条件，为数字n的时候意味着行驶里程小于等于n万公里
            gearbox: 0, //	int	否	变速箱类型 0或空为不筛选此条件 数字时为变速箱的类型，自动，手动等
            fueltype: 0, //	int	否	燃料类别（0不限，1汽油、2柴油、3纯电动、4油电混合）
            seatnum: 0, //int	否	座位数（0-不限，2-2座，4-4座，5-5座，7-7座,8-7座以上）
            displacementmin: 0, //	float	否	排量筛选最小值 空为不筛选此条件，0为大于等于0L
            displacementmax: 0, //	float	否	排量筛选最大值 空为不筛选此条件，为数字n的时候意味着小于等于nL
            color: 0, //	int	否	车辆颜色 0或空为不筛选此条件
            country: 0, //	int	否	产地 0或空为不筛选此条件 数字时为国别，自主。合资，进口等
            mortgage: 0, //int	否	半价车 1半价车 -1为非半价车，0、空：全价车 2:半价车+全价车
            orderprice: 0, //	int	否	价格排序：0或null排序不使用价格； 1从小到大； 2从大到小
            orderage: 0, //int	否	车龄排序：0或null排序不使用价格；1从新到旧；2从旧到新
            ordermileage: 0, //	int	否	里程排序：0或null排序不使用里程；1从小到大； 2从大到小
            onlycount: 0, //	int	否	1为只返回总数/ 默认值0
            onlyperson: 0, //	int	否	只返回个人车源：1只返回个人车源
            quality_query_type: 0, //	int	否	车源类型： 0：全部车源；1：无事故承诺； 5：优信认证；6：付一成
            distance_asc: 0, //int	否	1：距离最近
            country_type: 0, //int	否	国别（不限、德系、日系、韩系、美系、法系、国产、非国产、非日系 分别用 0- 8 的数字表示）
            longitude: '', //	string	否	地理位置 -经度
            latitude: '', //	string	否	地理位置 -纬度
            os: 'wap',
            n_p: '', //页码）,c_p（页码）,multi_mode_word（分词）,
            zg_num: '' //（页码）,loc_num（页码）int	否 	 接口返回，客户端接收到直接带回即可，不需要处理逻辑
        },
        initParams: {
            cityid: 201, //int	是	定位或者用户选择的城市单个城市ID，如201
            search_cityid: 201, //	string	是	搜索城市id，区域时传递多个城市ID组成的字符串,201,2601,901；单个城市时同cityid字段
            offset: 0, //int	是	首次传0，后面接收服务端返回下次请求带过来即可。（只需要传递过来即可，不需要任何计算）
            only_local: 0, //	int	是	只加载本地车源 开关 ，1：只加载本地车源、0：本地+直购车源 ，不传默认是0
            keyword: '', //	str	否	搜索关键词
            query: '', //	str	否	suggest词（搜索框）
            brandid: 0, //	int	否	品牌 0或空为不筛选此条件
            serieid: 0, //int	否	车系 0或空为不筛选此条件，多车系传递类似后面的格式 ，1993_449_382_391
            modelid: 0, //	int	否	车型 0或空为不筛选此条件 有车型的时候品牌和车系条件无效
            caridhiddenlist: '', //	str	否	不显示的车id列表，多个车id用英文逗号,分割，caridhiddenlist中的车将不显示在列表中
            category: 0, //	int	否	车型分类 0或空为不筛选此条件 数字时为车型的分类，suv，小型车，中型车等
            pricemin: 0, //	int	否	车辆价格筛选最小值 空为不筛选此条件，0为大于等于0元
            pricemax: 0, //int	否	车辆价格筛选最大值 空为不筛选此条件，为数字n的时候意味着价格小于等于n万元
            agemin: 0, //	int	否	车龄筛选最小值（0,1,2,3 这种数值）
            agemax: 0, //	int	否	车龄筛选最大值（0,1,2,3 这种数值） 0或空为不筛选此条件(如5年以上的时候此值可为空或数字0，只传最小值agemin=5 即可）
            mileagemin: 0, //	int	否	行驶里程筛选最小值 空为不筛选此条件，0为大于等于0万公里
            mileagemax: 0, //	int	否	行驶里程筛选最大值 空为不筛选此条件，为数字n的时候意味着行驶里程小于等于n万公里
            gearbox: 0, //	int	否	变速箱类型 0或空为不筛选此条件 数字时为变速箱的类型，自动，手动等
            fueltype: 0, //	int	否	燃料类别（0不限，1汽油、2柴油、3纯电动、4油电混合）
            seatnum: 0, //int	否	座位数（0-不限，2-2座，4-4座，5-5座，7-7座,8-7座以上）
            displacementmin: 0, //	float	否	排量筛选最小值 空为不筛选此条件，0为大于等于0L
            displacementmax: 0, //	float	否	排量筛选最大值 空为不筛选此条件，为数字n的时候意味着小于等于nL
            color: 0, //	int	否	车辆颜色 0或空为不筛选此条件
            country: 0, //	int	否	产地 0或空为不筛选此条件 数字时为国别，自主。合资，进口等
            mortgage: 0, //int	否	半价车 1半价车 -1为非半价车，0、空：全价车 2:半价车+全价车
            orderprice: 0, //	int	否	价格排序：0或null排序不使用价格； 1从小到大； 2从大到小
            orderage: 0, //int	否	车龄排序：0或null排序不使用价格；1从新到旧；2从旧到新
            ordermileage: 0, //	int	否	里程排序：0或null排序不使用里程；1从小到大； 2从大到小
            onlycount: 0, //	int	否	1为只返回总数/ 默认值0
            onlyperson: 0, //	int	否	只返回个人车源：1只返回个人车源
            quality_query_type: 0, //	int	否	车源类型： 0：全部车源；1：无事故承诺； 5：优信认证；6：付一成
            distance_asc: 0, //int	否	1：距离最近
            country_type: 0, //int	否	国别（不限、德系、日系、韩系、美系、法系、国产、非国产、非日系 分别用 0- 8 的数字表示）
            longitude: '', //	string	否	地理位置 -经度
            latitude: '', //	string	否	地理位置 -纬度
            os: 'wap',
            n_p: '', //（页码）//c_p（页码）,multi_mode_word（分词）,
            zg_num: '', //（页码）//loc_num（页码）int	否 	 接口返回，客户端接收到直接带回即可，不需要处理逻辑
            multi_mode_word: '',
            search_bsms: {}
        },
        carList: [],
        sorts: [{
            name: "默认排序",
            nameStr: 'defaultSort',
            value: ''
        }, {
            name: "价格最低",
            nameStr: "orderprice",
            value: 1
        }, {
            name: "价格最高",
            nameStr: "orderprice",
            value: 2
        }, {
            name: "车龄最短",
            nameStr: "orderage",
            value: 1
        }, {
            name: "里程最少",
            nameStr: "ordermileage",
            value: 1
        }, {
            name: "最新发布",
            nameStr: "first_publishtime",
            value: 1
        }, {
            name: "距离最近",
            nameStr: 'distance_asc',
            value: 1
        }],
        prices: [{
            pricemin: 0,
            pricemax: '',
            name: '不限'
        }, {
            pricemin: 0,
            pricemax: 3,
            name: '3万以下'
        }, {
            pricemin: 0,
            pricemax: 5,
            name: '3-5万'
        }, {
            pricemin: 5,
            pricemax: 10,
            name: '5-10万'
        }, {
            pricemin: 10,
            pricemax: 15,
            name: '10-15万'
        }, {
            pricemin: 15,
            pricemax: 20,
            name: '15-20万'
        }, {
            pricemin: 20,
            pricemax: 30,
            name: '20-30万'
        }, {
            pricemin: 30,
            pricemax: 50,
            name: '30-50万'
        }, {
            pricemin: 50,
            pricemax: '',
            name: '50万以上'
        }],
        tabIndex: 0,
        sortOn: 0,
        priceOn: 0,
        tabName: ['排序', '品牌', '价格', '筛选'],
        city: {
            cityid: 1,
            cityname: '全国'
        }
    },
    onShow: function onShow() {
        var that = this;
        swan.getStorage({ //取出数据params
            key: 'ajaxparams',
            success: function success(res) {
                var ajaxparams = res.data ? res.data : '';
                console.log(ajaxparams);
                if (ajaxparams) {
                    that.setData({
                        ajaxParams: ajaxparams
                    });
                }
                that.getListData();
            },
            fail: function fail(res) {
                that.getListData();
            }
        });
        swan.getStorage({ //取出城市信息数据
            // 数据params
            key: 'city',
            success: function success(res) {
                console.log(res.data);
                that.setData({
                    city: res.data
                });
            },
            fail: function fail(res) {
                console.log("获取数据失败" + res);
                var city = { cityid: 1, cityname: '全国' };
                that.setData({
                    city: city
                });
            }
        });
    },
    onReachBottom: function onReachBottom() {
        var isLazyLoad = true;
        this.getListData(isLazyLoad);
    },
    getListData: function getListData(isLazyLoad) {
        var that = this;
        that.data.ajaxParams.offset = isLazyLoad ? that.data.ajaxParams.offset : 0;
        !isLazyLoad && that.setData({
            carList: []
        });
        var baseCarList = that.data.carList;
        var isAbleRequest = that.data.isAbleRequest;
        if (isAbleRequest) {
            that.setData({
                isAbleRequest: false
            });
            swan.request({
                url: 'https://baidu.xin.com/car_search/search', //开发者服务器接口地址
                method: 'GET',
                dataType: 'json',
                data: that.data.ajaxParams,
                header: {
                    'content-type': 'application/json' // 默认值
                },
                success: function success(res) {
                    that.setData({
                        isAbleRequest: true
                    });
                    res.data.data.list.length > 0 && res.data.data.list.forEach(function (item) {
                        baseCarList.push(item);
                    });
                    res.data.data.list.length < 20 && that.setData({ loadMoreText: '没有更多数据了', isHideLoadMore: true });
                    var carList = baseCarList;
                    that.data.ajaxParams.offset = res.data.data.offset;
                    that.setData({
                        carList: carList,
                        total: res.data.data.total
                    });
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        } else {
            return;
        }
    },
    onSearch: function onSearch(e) {
        //搜索想要的车
        swan.navigateTo({
            url: 'pages/search/search'
        });
    },
    chooseCity: function chooseCity() {
        //选择城市
        swan.navigateTo({
            "url": "pages/chioce-city/chioce-city?chooseType=list"
        });
    },
    oneItemClick: function oneItemClick(e) {
        var carid = e.target.dataset.carid;
        var cityid = this.data.ajaxParams.cityid;
        swan.navigateTo({
            'url': 'pages/detail/detail?carid=' + carid + '&cityid=' + cityid
        });
    },
    closeSort: function closeSort(e) {
        this.setData({
            tabIndex: 0
        });
    },
    tabClick: function tabClick(e) {

        var tabIndex = e.target.dataset.index;
        if (this.data.tabIndex === tabIndex) {
            this.setData({
                tabIndex: 0
            });
        } else {
            this.setData({
                tabIndex: tabIndex
            });
        };
    },
    sortClick: function sortClick(e) {
        var _this = this;

        //排序
        var index = e.target.dataset.index;
        var sortArr = this.data.sorts;
        sortArr.forEach(function (item, sortIndex) {
            var nameStr = item.nameStr;
            _this.data.ajaxParams[nameStr] = '';
        });
        var sortName = sortArr[index].nameStr;
        this.data.ajaxParams[sortName] = sortArr[index].value;
        this.data.tabName[0] = sortArr[index].name;
        this.setData({
            tabIndex: 0,
            sortOn: index,
            tabName: this.data.tabName
        });
        this.getListData();
    },
    priceClick: function priceClick(e) {
        //价格
        var index = e.target.dataset.index;
        var priceArr = this.data.prices[index];
        this.data.ajaxParams.pricemin = priceArr.pricemin;
        this.data.ajaxParams.pricemax = priceArr.pricemax;
        this.data.tabName[2] = priceArr.name;
        console.log(priceArr.name);
        this.setData({
            tabIndex: 0,
            priceOn: index,
            tabName: this.data.tabName
        });
        this.getListData();
    },
    //品牌选择
    onClickBrand: function onClickBrand() {
        swan.navigateTo({
            'url': 'pages/chioce-brand/chioce-brand?pageName=carlist&params=' + encodeURIComponent(JSON.stringify(this.data.ajaxParams))
        });
    },
    // 筛选
    openScreen: function openScreen(e) {
        var ajaxparams = this.data.ajaxParams;
        ajaxparams.total = this.data.total;
        swan.setStorage({
            key: 'ajaxparams',
            data: ajaxparams,
            success: function success(res) {
                swan.navigateTo({
                    'url': 'pages/carlist-screen/carlist-screen'
                });
            },
            fail: function fail(err) {
                console.log('set fail');
            }
        });
    },
    capsuleAll: function capsuleAll() {
        // 胶囊全部
        this.data.ajaxParams.quality_query_type = 0;
        this.getListData();
        this.setData({
            allCar: true,
            halfCar: false
        });
    },
    capsuleHalf: function capsuleHalf() {
        //胶囊一成购
        this.data.ajaxParams.quality_query_type = 6;
        this.getListData();
        this.setData({
            allCar: false,
            halfCar: true
        });
    }
});});

/***/ }),
/* 62 */
/***/ (function(module, exports) {

PageDefine('pages/carlist-screen/carlist-screen', function (Page, getApp) {'use strict';

/**
 * @file carlist-screen page for swan
 * @author chenwei4(chenwei4.xin.com)
 */

Page({
    data: {
        ajaxParams: {},
        colorClass: 'hide',
        total: 0,
        colorname: '不限',
        brandCons: [{
            title: '不限',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-1.png',
            vaule: 0
        }, {
            title: 'SUV',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-2.png',
            value: 8
        }, {
            title: 'MPV',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-3.png',
            value: 7
        }, {
            title: '面包车',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-4.png',
            value: 10
        }, {
            title: '跑车',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-5.png',
            value: 9
        }, {
            title: '中型车',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-6.png',
            value: 4
        }, {
            title: '紧凑车',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-6.png',
            value: 3
        }, {
            title: '豪华车',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-6.png',
            value: 6
        }, {
            title: '中大型',
            imgsrc: 'http://s4.xinstatic.com/m/img/smallprogram/car-6.png',
            value: 5
        }],
        speeds: [{
            title: '不限',
            value: 0
        }, {
            title: '手动挡',
            value: 1

        }, {
            title: '自动挡',
            value: 2
        }],
        sources: [{
            title: '不限',
            value: 0
        }, {
            title: '本地车源',
            value: 1
        }, {
            title: '一成购',
            value: 2
        }],
        carAges: [{
            agemin: 0,
            agemax: '',
            title: '不限'
        }, {
            agemin: 0,
            agemax: 1,
            title: '1年以下'
        }, {
            agemin: 1,
            agemax: 2,
            title: '1-2年'
        }, {
            agemin: 2,
            agemax: 3,
            title: '2-3年'
        }, {
            agemin: 3,
            agemax: 5,
            title: '3-5年'
        }, {
            agemin: 5,
            agemax: '',
            title: '5年以上'
        }],
        mileages: [{
            mileagemin: 0,
            mileagemax: '',
            title: '不限'
        }, {
            mileagemin: 0,
            mileagemax: 3,
            title: '3万以下'
        }, {
            mileagemin: 3,
            mileagemax: 6,
            title: '3-6万'
        }, {
            mileagemin: 6,
            mileagemax: 9,
            title: '6-9万'
        }, {
            mileagemin: 9,
            mileagemax: 12,
            title: '9-12万'
        }, {
            mileagemin: 12,
            mileagemax: '',
            title: '12万以上'
        }],
        volumes: [{
            displacementmin: 0,
            displacementmax: '',
            title: '不限'
        }, {
            displacementmin: 0,
            displacementmax: 1,
            title: '1.0以下'
        }, {
            displacementmin: 1,
            displacementmax: 2,
            title: '1.0-2.0'
        }, {
            displacementmin: 2,
            displacementmax: 3,
            title: '2.0-3.0'
        }, {
            displacementmin: 3,
            displacementmax: 4,
            title: '3.0-4.0'
        }, {
            displacementmin: 4,
            displacementmax: '',
            title: '4.0以上'
        }],
        emissions: [{
            emission_standard: 0,
            title: '不限'
        }, {
            emission_standard: 1,
            title: '国三以上'
        }, {
            emission_standard: 2,
            title: '国四以上'
        }, {
            emission_standard: 3,
            title: '国五'
        }],
        colors: [{
            ctext: "★",
            data: [{
                colorText: "不限颜色",
                value: 0
            }]
        }, {
            ctext: "颜色",
            data: [{
                colorText: "黑色",
                value: 1
            }, {
                colorText: "深灰色",
                value: 2
            }, {
                colorText: "银灰色",
                value: 3
            }, {
                colorText: "白色",
                value: 4
            }, {
                colorText: "香槟色",
                value: 5
            }, {
                colorText: "黄色",
                value: 6
            }, {
                colorText: "橙色",
                value: 7
            }, {
                colorText: "红色",
                value: 8
            }, {
                colorText: "粉红色",
                value: 9
            }, {
                colorText: "紫色",
                value: 10
            }, {
                colorText: "蓝色",
                value: 11
            }, {
                colorText: "绿色",
                value: 12
            }, {
                colorText: "咖啡色",
                value: 13
            }, {
                colorText: "多彩色",
                value: 14
            }, {
                colorText: "其他",
                value: 15
            }]
        }],
        brandConOn: 0,
        speedOn: 0,
        sourceOn: 0,
        carAgeOn: 0,
        mileageOn: 0,
        volumeOn: 0,
        emissionOn: 0,
        colorOn: 0
    },

    onShow: function onShow() {
        var that = this;
        swan.getStorage({ //取出数据params
            key: 'ajaxparams',
            success: function success(res) {
                var ajaxparams = res.data ? res.data : {};
                that.setData({
                    ajaxParams: ajaxparams,
                    total: ajaxparams.total || 0,
                    brandConOn: ajaxparams.brandConOn || 0,
                    speedOn: ajaxparams.speedOn || 0,
                    sourceOn: ajaxparams.sourceOn || 0,
                    carAgeOn: ajaxparams.carAgeOn || 0,
                    mileageOn: ajaxparams.mileageOn || 0,
                    volumeOn: ajaxparams.volumeOn || 0,
                    emissionOn: ajaxparams.emissionOn || 0,
                    colorname: ajaxparams.colorname || '不限',
                    colorOn: ajaxparams.color || 0
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    getListData: function getListData() {
        var params = this.data.ajaxParams;
        var that = this;
        swan.request({
            url: 'https://baidu.xin.com/car_search/search', //开发者服务器接口地址
            method: 'GET',
            dataType: 'json',
            data: params,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success: function success(res) {
                var total = res.data.data.total;
                that.setData({
                    total: total
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    categoryClick: function categoryClick(e) {
        //车型
        var index = e.target.dataset.index;
        var categoryValue = this.data.brandCons[index].value;
        var category = this.data.ajaxParams;
        this.data.ajaxParams.category = categoryValue;
        this.data.ajaxParams.brandConOn = index;
        this.setData({
            brandConOn: index
        });
        this.getListData();
    },
    speedClick: function speedClick(e) {
        //变速箱
        var index = e.target.dataset.index;
        this.data.ajaxParams.gearbox = this.data.speeds[index].value;
        this.data.ajaxParams.speedOn = index;
        this.setData({
            speedOn: index
        });
        this.getListData();
    },
    sourceClick: function sourceClick(e) {
        //车源类型
        var index = e.target.dataset.index;
        this.data.ajaxParams.quality_query_type = this.data.sources[index].value;
        this.data.ajaxParams.sourceOn = index;
        this.setData({
            sourceOn: index
        });
        this.getListData();
    },
    carAgeClick: function carAgeClick(e) {
        //车龄
        var index = e.target.dataset.index;
        this.data.ajaxParams.agemin = this.data.carAges[index].agemin;
        this.data.ajaxParams.agemax = this.data.carAges[index].agemax;
        this.data.ajaxParams.carAgeOn = index;
        this.setData({
            carAgeOn: index
        });
        this.getListData();
    },
    mileageClick: function mileageClick(e) {
        //里程
        var index = e.target.dataset.index;
        this.data.ajaxParams.mileagemin = this.data.mileages[index].mileagemin;
        this.data.ajaxParams.mileagemax = this.data.mileages[index].mileagemax;
        this.data.ajaxParams.mileageOn = index;
        this.setData({
            mileageOn: index
        });
        this.getListData();
    },
    volumeClick: function volumeClick(e) {
        //排量
        var index = e.target.dataset.index;
        this.data.ajaxParams.displacementmin = this.data.volumes[index].displacementmin;
        this.data.ajaxParams.displacementmax = this.data.volumes[index].displacementmax;
        this.data.ajaxParams.volumeOn = index;
        this.setData({
            volumeOn: index
        });
        this.getListData();
    },
    emissionClick: function emissionClick(e) {
        //排放标准
        var index = e.target.dataset.index;
        this.data.ajaxParams.emission_standard = this.data.emissions[index].emission_standard;
        this.data.ajaxParams.emissionOn = index;
        this.setData({
            emissionOn: index
        });
        this.getListData();
    },
    chooseColor: function chooseColor(e) {
        //选择颜色
        this.setData({
            screenClass: 'hide',
            colorClass: 'show'
        });
    },
    colorClick: function colorClick(e) {
        var colorname = e.target.dataset.colorname;
        var value = e.target.dataset.value;
        this.data.ajaxParams.color = value;
        this.data.ajaxParams.colorname = colorname;
        this.setData({
            screenClass: 'show',
            colorClass: 'hide',
            colorname: colorname
        });

        this.getListData();
    },
    subClick: function subClick() {
        // 查看车辆
        var selectNum = 0;
        var selectObj = {
            brandConOn: this.data.brandConOn,
            speedOn: this.data.speedOn,
            sourceOn: this.data.sourceOn,
            carAgeOn: this.data.carAgeOn,
            mileageOn: this.data.mileageOn,
            volumeOn: this.data.volumeOn,
            emissionOn: this.data.emissionOn,
            colorOn: this.data.colorOn
        };
        for (var k in selectObj) {
            if (selectObj[k] !== 0) {
                selectNum += 1;
            }
        }
        var ajaxparams = this.data.ajaxParams;
        ajaxparams.selectNum = selectNum;
        console.log(selectNum);
        swan.removeStorage({
            key: 'ajaxparams',
            success: function success(res) {
                console.log('success');
            },
            fail: function fail(err) {
                console.log('fail');
            }
        });
        swan.setStorage({
            key: 'ajaxparams',
            data: ajaxparams,
            success: function success(res) {
                swan.switchTab({
                    url: 'pages/carlist/carlist',
                    success: function success(res) {
                        console.log(res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            }
        });
    },
    resClick: function resClick() {
        //重置
        this.setData({
            brandConOn: 0,
            speedOn: 0,
            sourceOn: 0,
            carAgeOn: 0,
            mileageOn: 0,
            volumeOn: 0,
            emissionOn: 0,
            colorOn: 0,
            colorname: '不限'
        });
        this.data.ajaxParams.category = 0; // 车型
        this.data.ajaxParams.gearbox = 0; //变速箱
        this.data.ajaxParams.quality_query_type = 0; //车源类型
        this.data.ajaxParams.agemin = 0; //车龄
        this.data.ajaxParams.agemax = ''; //车龄
        this.data.ajaxParams.mileagemin = 0; //里程
        this.data.ajaxParams.mileagemax = ''; //里程
        this.data.ajaxParams.displacementmin = 0; //排量
        this.data.ajaxParams.displacementmax = ''; //排量
        this.data.ajaxParams.emission_standard = 0; //排放标准
        this.data.ajaxParams.color = 0; // 颜色
        this.getListData();
    },
    oneItemTouchStart: function oneItemTouchStart() {
        console.log('oneItemTouchStart');
    },

    oneItemTouchEnd: function oneItemTouchEnd() {
        console.log('oneItemTouchEnd');
    },

    scfunc: function scfunc() {
        console.log('scfunc');
    }
});});

/***/ }),
/* 63 */
/***/ (function(module, exports) {

PageDefine('pages/carlist-color/carlist-color', function (Page, getApp) {"use strict";

/**
 * @file carlist-color page for swan
 * @author chenwei4(chenwei4.xin.com)
 */

Page({
    data: {
        colors: [{
            ctext: "★",
            data: [{
                colorText: "不限颜色",
                value: 0
            }]
        }, {
            ctext: "颜色",
            data: [{
                colorText: "黑色",
                value: 1
            }, {
                colorText: "深灰色",
                value: 2
            }, {
                colorText: "银灰色",
                value: 3
            }, {
                colorText: "白色",
                value: 4
            }, {
                colorText: "香槟色",
                value: 5
            }, {
                colorText: "黄色",
                value: 6
            }, {
                colorText: "橙色",
                value: 7
            }, {
                colorText: "红色",
                value: 8
            }, {
                colorText: "粉红色",
                value: 9
            }, {
                colorText: "紫色",
                value: 10
            }, {
                colorText: "蓝色",
                value: 11
            }, {
                colorText: "绿色",
                value: 12
            }, {
                colorText: "咖啡色",
                value: 13
            }, {
                colorText: "多彩色",
                value: 14
            }, {
                colorText: "其他",
                value: 15
            }]
        }]
    },
    colorClick: function colorClick(e) {
        swan.navigateTo({
            'url': 'pages/carlist-screen/carlist-screen'
        });
    },
    oneItemTouchStart: function oneItemTouchStart() {
        console.log('oneItemTouchStart');
    },

    oneItemTouchEnd: function oneItemTouchEnd() {
        console.log('oneItemTouchEnd');
    },

    onLoad: function onLoad() {
        console.log('page-init');
    },

    onReady: function onReady() {
        console.log('onReady');
    },

    onShow: function onShow() {
        console.log('onShow');
    },

    onHide: function onHide() {
        console.log('onHide');
    },

    scfunc: function scfunc() {
        console.log('scfunc');
    }
});});

/***/ }),
/* 64 */
/***/ (function(module, exports) {

PageDefine('pages/direct_purchase/direct_purchase', function (Page, getApp) {"use strict";

Page({
    data: {
        host: 'https://baidu.xin.com',
        data: null,
        city: null
    },
    chooseCity: function chooseCity() {
        swan.navigateTo({
            "url": "pages/chioce-city/chioce-city"
        });
    },
    freeCall: function freeCall() {
        swan.navigateTo({
            "url": "pages/freeCall/freeCall"
        });
    },
    phoneResult: function phoneResult() {
        var host = this.data.host;
        swan.request({
            url: host + "/telephone/get_crm_tele",
            dataType: 'json',
            header: {
                'content-type': 'application/json' // 默认值
            },
            data: {
                carid: 73251395,
                cityid: 201,
                os: "wap"
            },
            success: function success(res) {
                console.log('400电话' + res.data.data);
                var mobileNum = res.data.data;
                swan.makePhoneCall({
                    phoneNumber: mobileNum, //仅为示例，并非真实的电话号码
                    success: function success(res) {
                        console.log("400动态电话拨打成功" + res);
                    },
                    fail: function fail(err) {
                        console.log(err);
                    }
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    },
    onLoad: function onLoad(option) {
        var _this = this;

        console.log("全国直购页的信息" + JSON.stringify(option));
        var carid = option.carid,
            carcityid = option.carcityid; // 获取从详情页传过来的参数

        swan.setNavigationBarTitle({
            title: '全国直购',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
        console.log(option);
        var host = this.data.host;
        swan.getStorage({
            key: 'city',
            success: function success(res) {
                var cityid = res.data.cityid;
                console.log("返回的城市id ========》" + cityid);
                swan.request({ //获取直购方案的数据
                    url: host + '/car_detail_new/direct_purchase_wap',
                    dataType: 'json',
                    data: { /*参数需要从上一个页面传递*/
                        cityid: cityid,
                        carid: carid,
                        currentcityid: cityid,
                        carcityid: carcityid,
                        mobile_type: 0,
                        os: 'wap'
                    },
                    header: {
                        'content-type': 'application/json' // 默认值
                    },
                    success: function success(res) {
                        var data = res.data.data;
                        _this.setData({
                            data: data
                        });
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }
});});

/***/ }),
/* 65 */
/***/ (function(module, exports) {

PageDefine('pages/identify/identify', function (Page, getApp) {'use strict';

Page({
    goShopClick: function goShopClick() {
        swan.switchTab({
            url: 'pages/carlist/carlist',
            success: function success(res) {
                console.log(res + '这是列表页');
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    onLoad: function onLoad() {
        swan.setNavigationBarTitle({
            title: '车辆详情',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ }),
/* 66 */
/***/ (function(module, exports) {

PageDefine('pages/sellCar/sellCar', function (Page, getApp) {"use strict";

Page({
    data: {
        host: "https://baidu.xin.com",
        num: '',
        bottomHidden: "none",
        current: 10,
        text: ''
    },
    onLoad: function onLoad() {
        this.toRequest();
        swan.setNavigationBarTitle({
            title: '我要卖车',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    onShow: function onShow() {
        this.toRequest();
    },
    toRequest: function toRequest() {
        var _this = this;

        var host = this.data.host;
        swan.request({
            url: host + '/customer/c2b_material', //开发者服务器接口地址
            method: 'GET',
            dataType: 'json',
            header: {
                'content-type': 'application/json' // 默认值
            },
            data: {
                cityid: 1,
                search_cityid: 1,
                os: 'wap'
            },
            success: function success(res) {
                console.log("在售数量" + JSON.stringify(res.data));
                var data = res.data.data;
                _this.setData({
                    num: data.total
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    isShowClick: function isShowClick(e) {
        if (e.target.dataset.current === this.data.current) {
            this.setData({
                current: 100
            });
        } else {
            this.setData({
                current: e.target.dataset.current
            });
        }
    },
    orderSellerCar: function orderSellerCar() {
        swan.navigateTo({
            url: 'pages/orderSeller/orderSeller',
            success: function success(res) {
                swan.setStorage({
                    key: 'isSeller',
                    data: '1',
                    success: function success(res) {
                        console.log("埋下的isSeller为1" + res);
                    },
                    fail: function fail(res) {
                        console.log(+res);
                    }
                });
            },
            fail: function fail(res) {
                console.log(+res);
            }
        });
    },
    accessPrice: function accessPrice() {
        swan.navigateTo({
            'url': 'pages/orderSeller/orderSeller',
            success: function success(res) {
                swan.setStorage({
                    key: 'isSeller',
                    data: '0',
                    success: function success(res) {
                        console.log("埋下的isSeller为0" + res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    freeConsultClick: function freeConsultClick() {
        //免费咨询
        swan.makePhoneCall({
            phoneNumber: '4006131628', //仅为示例，并非真实的电话号码
            success: function success(res) {
                console.log(res + "打通电话啦");
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }
});});

/***/ }),
/* 67 */
/***/ (function(module, exports) {

PageDefine('pages/chioce-city/chioce-city', function (Page, getApp) {'use strict';

//城市选择
Page({
    data: {
        host: 'https://baidu.xin.com',
        cities: null,
        hotAreaList: [],
        preLetterList: [],
        currentIndex1: 100,
        currentLetter: '',
        params: null,
        currentCity: null,
        isSellCity: '',
        onlyList: true
    },
    onChooseCityClick: function onChooseCityClick(e) {
        var params = this.data.params;
        var _e$target$dataset = e.target.dataset,
            cityname = _e$target$dataset.cityname,
            sell = _e$target$dataset.sell;

        var cityid = e.target.dataset.cityid * 1;
        var city = {
            cityid: cityid,
            cityname: cityname
        };
        if (params.chooseType === 'sell') {
            if (sell === 1) {
                swan.setStorage({
                    key: 'sellCity',
                    data: city,
                    success: function success(res) {
                        swan.navigateTo({
                            url: 'pages/orderSeller/orderSeller',
                            success: function success(res) {
                                console.log("跳转页面成功:::" + res);
                            },
                            fail: function fail(res) {
                                console.log('跳转页面失败:::' + JSON.stringify(res));
                            }
                        });
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            } else {
                swan.showModal({
                    title: '提示',
                    content: '你选择的城市暂不支持卖车业务，请选择周边其他城市',
                    cancelColor: '#999999',
                    showCancel: false,
                    confirmColor: '#0099cc',
                    success: function success(res) {
                        console.log(res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            }
        }
        if (params.chooseType === 'plate') {
            swan.setStorage({
                key: 'plateCity',
                data: city,
                success: function success(res) {
                    swan.navigateTo({
                        url: 'pages/orderSeller/orderSeller',
                        success: function success(res) {
                            console.log("跳转页面成功:::" + res);
                        },
                        fail: function fail(res) {
                            console.log('跳转页面失败:::' + JSON.stringify(res));
                        }
                    });
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        }
        if (params.chooseType === 'home') {
            swan.setStorage({
                key: 'city',
                data: city,
                success: function success(res) {
                    swan.switchTab({
                        url: 'pages/home/home',
                        success: function success(res) {
                            console.log(res);
                        },
                        fail: function fail(res) {
                            console.log(res);
                        }
                    });
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        }
        if (params.chooseType === 'list') {
            this.setData({
                sellCity: 'no'
            });
            swan.setStorage({
                key: 'city',
                data: city,
                success: function success(res) {
                    swan.switchTab({
                        url: 'pages/carlist/carlist',
                        success: function success(res) {
                            console.log(res);
                        },
                        fail: function fail(res) {
                            console.log(res);
                        }
                    });
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        }
    },
    onLoad: function onLoad(option) {
        var _this = this;

        swan.setNavigationBarTitle({
            title: '城市选择',
            success: function success(res) {
                console.log('success:::' + JSON.stringify(res));
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
        console.log(" 城市页传来的参数" + JSON.stringify(option));
        /*方便其他事件使用别的页面传过来的数据*/
        this.setData({
            params: option
        });
        if (option.chooseType === "sell") {
            this.setData({
                isSellCity: 'yes',
                onlyList: false
            });
        } else if (option.chooseType === "plate") {
            this.setData({
                isSellCity: 'no',
                onlyList: true
            });
        } else {
            this.setData({
                isSellCity: 'no',
                onlyList: true
            });
        }
        swan.request({
            url: 'https://baidu.xin.com/city/viewall', //开发者服务器接口地址
            method: 'GET',
            dataType: 'string',
            header: {
                'content-type': 'application/json' // 默认值
            },
            success: function success(res) {
                console.log("城市页返回的信心" + JSON.parse(res.data).data);
                var data = JSON.parse(res.data).data;
                var lists = Object.keys(data).slice(2);
                _this.setData({
                    cities: data,
                    hotAreaList: data["热门城市"],
                    preLetterList: lists
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        swan.getStorage({
            key: 'city',
            success: function success(res) {
                var currentCity = res.data;
                _this.setData({
                    currentCity: currentCity
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }
});});

/***/ }),
/* 68 */
/***/ (function(module, exports) {

PageDefine('pages/chioce-brand/chioce-brand', function (Page, getApp) {'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Page({
    data: _defineProperty({
        carTypeParams: {},
        isPicShow: true,
        moveNum: 0,
        isCarShow: false,
        num: 0,
        preLetterList: ['A', 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'W', 'X', 'Y', 'Z'],
        hotBrandList: [],
        brandList: {},
        currentSeriesList: null,
        carModelL: null,
        beforeData: {},
        chioceParam: {},
        isNoLimitShow: true
    }, 'isPicShow', true),
    GoCarList: function GoCarList(e) {
        swan.switchTab({
            url: 'pages/carlist/carlist'
        });
    },
    ChangeShow: function ChangeShow(e) {
        //控制车系车型的显现和数据获取
        var that = this;
        if (this.data.beforeData.pageName == 'orderSeller') {
            this.data.carTypeParams.showmodel = 1;
        }
        this.data.chioceParam.brandid = e.target.dataset.brandId; //往回传的参数
        this.data.chioceParam.carDetailName = e.target.dataset.brandName;
        if (this.data.beforeData.pageName == 'carlist') {
            this.data.beforeData.params.brandName = e.target.dataset.brandName;
        }
        this.setData('isCarShow', true);
        this.setData('moveNum', 1);
        this.data.carTypeParams.brandid = e.target.dataset.brandId;
        this.setData('carTypeParams', this.data.carTypeParams);
        console.log(this.data.carTypeParams);
        swan.request({ //获取车辆品牌下车型的数据
            url: 'https://baidu.xin.com/serie/view',
            dataType: 'string',
            data: this.data.carTypeParams,
            success: function success(res) {
                var finalRes = res.data ? JSON.parse(res.data).data : '';
                that.setData('currentSeriesList', finalRes);
                console.log(that.data.currentSeriesList);
            },
            fail: function fail(res) {
                console.log('brand err');
                console.log(res);
            }
        });
    },
    showToast: function showToast(e) {
        swan.showToast({
            title: e.target.dataset.text,
            icon: 'loading',
            duration: 1000,
            success: function success(res) {
                console.log(res + ":ok");
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    onCarType: function onCarType(e) {
        //type 往车型跳 serie是车系列表
        //console.log()
        var that = this;
        this.data.chioceParam.seriesid = e.target.dataset.serieId;
        this.data.chioceParam.carDetailName = this.data.chioceParam.carDetailName + "  " + e.target.dataset.serieName;

        if (this.data.beforeData.pageName == 'orderSeller') {
            //跳转到车型页面进行下一步操作
            swan.navigateTo({
                url: 'pages/chioce-carType/chioce-carType?model=' + encodeURIComponent(JSON.stringify(e.target.dataset.model)) + "&chioceParam=" + encodeURIComponent(JSON.stringify(this.data.chioceParam)),
                success: function success(res) {
                    console.log(res);
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        } else {
            //跳转到卖车列表页
            this.data.beforeData.params.serieid = e.target.dataset.serieId;
            //console.log(this.data.beforeData.params)
            var params = this.data.beforeData.params;
            params.brandid = '';
            params.query = '';
            console.log(params);
            swan.setStorage({
                key: 'ajaxparams',
                data: params,
                success: function success(res) {
                    console.log("任务成功");
                    that.GoCarList();
                },
                fail: function fail() {
                    console.log("任务失败");
                }
            });
        }
    },
    closeChioce: function closeChioce() {
        //滑动关闭车系表
        this.data.num++;
        if (this.data.isCarShow == true && this.data.num > 5) {
            this.setData('num', 0);
            this.setData('isCarShow', false);
            this.setData('moveNum', 0);
        }
    },
    NoLimit: function NoLimit() {
        var that = this;
        this.data.beforeData.params.brandName = "不限";
        this.data.beforeData.params.serieid = "";
        this.data.beforeData.params.brandid = "";
        swan.setStorage({
            key: 'ajaxparams',
            data: this.data.beforeData.params,
            success: function success() {
                that.GoCarList();
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        // let that = this
        //
        // var NoLimitParam = {}
        // NoLimitParam.cityid=this.data.beforeData.params.cityid;
        // NoLimitParam.cityname=this.data.beforeData.params.cityname;
        // NoLimitParam.brandName="不限";
        // NoLimitParam.serieid="";
        // NoLimitParam.brandid="";
        // swan.setStorage({
        //     key:'ajaxparams',
        //     data:NoLimitParam,
        //     success:function(){
        //         that.GoCarList()
        //     }
        // })
    },
    onLoad: function onLoad(option) {
        console.log("这是option:::");
        console.log(option);
        this.data.beforeData = option;
        this.data.beforeData.params = option.pageName == "carlist" ? JSON.parse(this.data.beforeData.params) : this.data.beforeData.params;
        console.log(this.data.beforeData);
        if (option.pageName == "orderSeller") {
            this.setData('isNoLimitShow', false);
            this.setData('isPicShow', false);
        }
        var that = this;
        swan.request({ //获取热门品牌的数据
            url: 'https://baidu.xin.com/brand/hot',
            dataType: 'json',
            data: {
                cityid: 201,
                os: 'ios'
            },
            success: function success(res) {
                console.log('brand');
                var finalRes = res.data.data;
                that.setData('hotBrandList', finalRes);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        swan.request({ //获取品牌列表
            url: 'https:baidu.xin.com/brand/view',
            dataType: 'json',
            success: function success(res) {
                console.log("获取品牌信息成功");

                that.setData('brandList', res.data.data);
            },
            fail: function fail(res) {
                console.log("获取品牌失败" + res);
            }
        });
    }

});});

/***/ }),
/* 69 */
/***/ (function(module, exports) {

PageDefine('pages/chioce-carType/chioce-carType', function (Page, getApp) {'use strict';

Page({
    data: {
        preLetterList: ['A', 'B', 'C', 'D', 'E', 'F'],
        carType: null,
        beforeData: null
    },
    onCarList: function onCarList(e) {
        console.log(e.target.dataset.modelId);
        this.data.beforeData.modeid = e.target.dataset.modelId;
        this.data.beforeData.carDetailName = this.data.beforeData.carDetailName + "  " + e.target.dataset.modelName;
        console.log(this.data.beforeData);
        swan.navigateTo({
            url: 'pages/orderSeller/orderSeller?chioceParam=' + encodeURIComponent(JSON.stringify(this.data.beforeData))
        });
    },
    onLoad: function onLoad(option) {
        console.log(option);
        this.setData('carType', JSON.parse(option.model));
        this.setData('beforeData', JSON.parse(option.chioceParam));
    }
});});

/***/ }),
/* 70 */
/***/ (function(module, exports) {

PageDefine('pages/orderSuccess/orderSuccess', function (Page, getApp) {'use strict';

Page({
    data: {
        host: 'https://baidu.xin.com',
        current: 10,
        initData: null
    },
    onLoad: function onLoad(option) {
        console.log("预约卖车页传过来的参数" + option.params);
        swan.setNavigationBarTitle({
            title: '预约卖车',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    isShowClick: function isShowClick(e) {
        if (e.target.dataset.current === this.data.current) {
            this.setData({
                current: 100
            });
        } else {
            this.setData({
                current: e.target.dataset.current
            });
        }
    }
});});

/***/ }),
/* 71 */
/***/ (function(module, exports) {

PageDefine('pages/freeCall/freeCall', function (Page, getApp) {'use strict';

Page({
    data: {
        telephoneNum: '222'
    },
    cancelValue: function cancelValue(e) {
        this.setDate('telephoneNum', '');
    }

});});

/***/ }),
/* 72 */
/***/ (function(module, exports) {

PageDefine('pages/orderSeller/orderSeller', function (Page, getApp) {'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

Page({
    data: {
        data: '', //公里数
        mobileNum: '0', //手机号
        series: "",
        isShow: false,
        date: '',
        text: '',
        num: 60,
        code: 0,
        isClickAble: true,
        btnText: '',
        isSeller: '',
        city: null,
        cityid: '',
        sellCity: null,
        plateCity: null,
        wd: '',
        jd: '',
        chooseBrand: null
    },
    onLoad: function onLoad(option) {
        var _this = this;

        if (option.chioceParam) {
            console.log('城市页返回的信息上牌城市1111111' + JSON.stringify(option.chioceParam));
            var chioceParam = JSON.parse(option.chioceParam);
            this.setData({
                chooseBrand: chioceParam
            });
        }
        swan.getLocation({
            type: 'wgs84',
            altitude: true,
            success: function success(res) {
                console.log(res.latitude);
                console.log(res.longitude);
                var wd = res.latitude + '';
                var jd = res.longitude + '';
                _this.setData({
                    wd: wd,
                    jd: jd
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        swan.getStorage({
            key: 'city',
            success: function success(res) {
                var city = res.data;
                var cityid = res.data.cityid;
                _this.setData({ cityid: cityid });
                swan.request({
                    url: 'https://api.xin.com/city/city_zg', //开发者服务器接口地址
                    method: 'GET',
                    dataType: 'json',
                    data: {
                        cityid: cityid
                    },
                    header: {
                        'content-type': 'application/json' // 默认值
                    },
                    success: function success(res) {
                        if (res.data.data.zhigou === 1) {
                            _this.setData({
                                city: city
                            });
                        }
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        swan.getStorage({
            key: 'isSeller',
            success: function success(res) {
                var isSeller = res.data;
                if (isSeller === "1") {
                    _this.setData({
                        isSeller: true,
                        btnText: '预约卖车'
                    });
                    swan.setNavigationBarTitle({
                        title: '预约卖车',
                        success: function success(res) {
                            console.log('success:::' + JSON.stringify(res));
                        },
                        fail: function fail(err) {
                            console.log('fail:::' + JSON.stringify(err));
                        }
                    });
                } else if (isSeller === "0") {
                    _this.setData({
                        isSeller: false,
                        btnText: '开始估价'
                    });
                    swan.setNavigationBarTitle({
                        title: '车辆估价',
                        success: function success(res) {
                            console.log('success:::' + JSON.stringify(res));
                        },
                        fail: function fail(err) {
                            console.log('fail:::' + JSON.stringify(err));
                        }
                    });
                }
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        this.setData({
            text: '获取验证码'
        });
    },
    showDate: function showDate() {},
    bindDateChange: function bindDateChange(e) {
        this.setData({
            date: e.detail.value
        });
    },
    isShowClick: function isShowClick(e) {
        var _this2 = this;

        function isShowToast(content) {
            window.swan.showToast({
                title: content,
                icon: 'loading',
                duration: 1000,
                success: function success(res) {
                    console.log(res);
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        }
        if (!this.data.sellCity) {
            isShowToast('请选择车辆出售城市');
            return;
        }
        if (!this.data.plateCity) {
            isShowToast('请选择车辆上牌城市');
            return;
        }
        if (!this.data.data) {
            isShowToast('请输入行驶里程');
            return;
        }
        if (!this.data.date) {
            isShowToast('请填写上牌日期');
            return;
        }
        var isSeller = this.data.isSeller;
        swan.getStorage({
            key: 'userMobile',
            success: function success(res) {
                console.log("getStorage 的结果 " + res.data);
                var userMobile = JSON.parse(res.data);
                var _data = _this2.data,
                    sellCity = _data.sellCity,
                    plateCity = _data.plateCity,
                    chooseBrand = _data.chooseBrand,
                    wd = _data.wd,
                    jd = _data.jd;

                var c2b_cityid = sellCity.cityid;
                var no_cityid = plateCity.cityid;
                var carDetailName = chooseBrand.carDetailName;

                var brandid = chooseBrand.brandid * 1;
                var seriesid = chooseBrand.seriesid * 1;
                var modeid = chooseBrand.modeid * 1;
                var date = _this2.data.date;
                var data = _this2.data.data + '';
                var params = {
                    carDetailName: carDetailName,
                    plateDate: date,
                    plateCity: plateCity.cityname,
                    data: data
                };
                if (isSeller) {
                    //    预约卖车提交
                    swan.request({
                        url: 'http://baidu.xin.com/customer/c2b_submit_new', //开发者服务器接口地址
                        method: 'GET',
                        dataType: 'json',
                        data: {
                            //可以存为对象直接赋值给data
                            c2b_cityid: c2b_cityid,
                            no_cityid: no_cityid,
                            brandid: brandid,
                            serieid: seriesid,
                            modelid: modeid,
                            regist_date: date,
                            mileage: data,
                            mobile: userMobile,
                            os: 'wap',
                            longitude: jd,
                            latitude: wd
                        },
                        header: {
                            'content-type': 'application/json' // 默认值
                        },
                        success: function success(res) {
                            console.log("预约卖车提交成功" + JSON.stringify(res));
                            /*跳转到预约成功页面，将用户填写的信息作为参数发送给该页面orderSuccess*/
                            swan.navigateTo({
                                url: 'pages/orderSuccess/orderSuccess?params=' + params,
                                success: function success(res) {
                                    console.log(res);
                                },
                                fail: function fail(res) {
                                    console.log(res);
                                }
                            });
                        },
                        fail: function fail(res) {
                            console.log(res);
                        }
                    });
                } else {
                    //    估价页提交，
                    swan.request({
                        url: 'https://api.xin.com/evaluate_new/detail', //开发者服务器接口地址
                        method: 'GET',
                        dataType: 'json',
                        data: {
                            //估价和预约提交字段名称不同
                            cityid: no_cityid,
                            registe_cityid: no_cityid,
                            brandid: brandid,
                            serieid: seriesid,
                            modelid: modeid,
                            regist_date: date,
                            mileage: data,
                            mobile: userMobile,
                            os: 'wap',
                            longitude: jd,
                            latitude: wd
                        },
                        header: {
                            'content-type': 'application/json' // 默认值
                        },
                        success: function success(res) {
                            // 成功后将返回的结果作为参数发送给估价成功页，返回的结果已经被处理，不需要再去JSON.parse
                            console.log("估价成功啦" + JSON.stringify(res.data));
                            var evaluate = res.data.data;
                            console.log("估价成功以后的结果" + JSON.stringify(evaluate) + "是不是" + evaluate);
                            swan.navigateTo({
                                url: 'pages/carAccess/carAccess?evaluate =' + evaluate + '&params= ' + params,
                                success: function success(res) {
                                    console.log(res);
                                },
                                fail: function fail(res) {
                                    console.log(res);
                                }
                            });
                        },
                        fail: function fail(res) {
                            console.log(res);
                        }
                    });
                }
            },
            fail: function fail(res) {
                console.log(res);
                var isShow = true;
                _this2.setData({
                    isShow: isShow
                });
            }
        });
    },
    getValue: function getValue(e) {
        if (e.detail.value > 60) {
            this.setData({
                data: 60
            });
            swan.showToast({
                title: '行驶里程不能超过60公里',
                icon: 'loading',
                duration: 1000,
                success: function success(res) {
                    console.log(res);
                },
                fail: function fail(res) {
                    console.log(res);
                }
            });
        } else {
            this.setData({
                data: e.detail.value
            });
        }
    },
    getCode: function getCode() {
        var mobileNum = this.data.mobileNum;
        var num = this.data.num;
        var that = this;
        function modal(content) {
            swan.showModal({
                title: content,
                content: content,
                cancelColor: '#999999',
                confirmColor: '#0099cc'
            });
        }
        if (mobileNum == 0) {
            modal("请输入手机号");
        } else if (!/^1(3|4|5|7|8)\d{9}$/.test(mobileNum)) {
            modal("请输入正确的手机号");
        } else {
            var tipText = '';
            var _num = this.data.num;
            var isClickAble = this.data.isClickAble;
            if (isClickAble) {
                swan.request({
                    url: "http://baidu.xin.com/user_center/sms_code", //开发者服务器接口地址
                    method: 'GET',
                    dataType: 'json',
                    data: {
                        mobile: mobileNum
                    },
                    header: {
                        'content-type': 'application/json' // 默认值
                    },
                    success: function success(res) {
                        console.log("发送请求成功" + res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
                isClickAble = false;
                that.sh = setInterval(function () {
                    _num--;
                    tipText = '(' + _num + 's)后发送';
                    if (_num < 0) {
                        clearInterval(that.sh);
                        _num = 60;
                        tipText = "获取验证码";
                        isClickAble = true;
                    }
                    that.setData({
                        text: tipText,
                        num: _num,
                        isClickAble: isClickAble
                    });
                }, 1000);
            } else {
                return;
            }
        }
    },
    getMobileNum: function getMobileNum(e) {
        console.log(e.detail.value);
        this.setData({
            mobileNum: e.detail.value
        });
        console.log("失去焦点时，获取手机号" + this.data.mobileNum);
    },
    getCodeNum: function getCodeNum(e) {
        this.setData({
            code: e.detail.value
        });
    },
    submitClick: function submitClick() {
        var _this3 = this;

        var mobileNum = this.data.mobileNum;
        var code = this.data.code;
        function identifyCode(content) {
            swan.showModal({
                title: '提示',
                content: content,
                cancelColor: '#999999',
                confirmColor: '#0099cc'
            });
        }
        if (code == 0) {
            identifyCode('请输入验证码');
        } else if (!/^\d{6}$/.test(code)) {
            identifyCode('请输入准确的验证码');
        } else {
            swan.request({
                url: 'http://baidu.xin.com/user_center/login', //开发者服务器接口地址
                method: 'GET',
                dataType: 'json',
                data: {
                    mobile: mobileNum,
                    smscode: code
                },
                header: {
                    'content-type': 'application/json' // 默认值
                },
                success: function success(res) {
                    console.log("返回的验证码" + JSON.stringify(res.data));
                    if (res.data.code == 2) {
                        console.log("发送验证成功" + res.data.data.mobile);
                        console.log('我想看看data' + res.data.code);
                        var mobile = res.data.data.mobile;
                        swan.setStorage({
                            key: 'userMobile',
                            data: mobile,
                            success: function success(res) {
                                console.log(" setStorage 成功" + res);
                                _this3.setData({
                                    isShow: false
                                });
                            },
                            fail: function fail(res) {
                                console.log(res);
                            }
                        });
                    } else {
                        identifyCode('验证码有误，请输入正确的验证码');
                    }
                },
                fail: function fail(res) {
                    console.log('fali:::' + res);
                }
            });
        }
    },
    onHide: function onHide() {
        console.log('onHide');
    },
    chooseSellCity: function chooseSellCity() {
        swan.navigateTo({
            url: 'pages/chioce-city/chioce-city?chooseType=sell',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    choosePlateCity: function choosePlateCity() {
        swan.navigateTo({
            url: 'pages/chioce-city/chioce-city?chooseType=plate',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    onShow: function onShow() {
        var _this4 = this;

        swan.getStorage({
            key: 'sellCity',
            success: function success(res) {
                var sellCity = res.data;
                console.log("上牌城市的城市id " + sellCity.cityid + "他是什么类型的" + _typeof(sellCity.cityid));
                _this4.setData({
                    sellCity: sellCity
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        swan.getStorage({
            key: 'plateCity',
            success: function success(res) {
                var plateCity = res.data;
                _this4.setData({
                    plateCity: plateCity
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    chooseCarClick: function chooseCarClick() {
        swan.getStorage({
            key: 'isSeller',
            success: function success(res) {
                console.log("isSeller" + res.data);
                var chooesDimension = res.data === "1" ? 'series' : 'type';
                console.log("chooesDimension" + chooesDimension + (typeof chooesDimension === 'undefined' ? 'undefined' : _typeof(chooesDimension)));
                swan.navigateTo({
                    url: 'pages/chioce-brand/chioce-brand?pageName=orderSeller&params=' + chooesDimension,
                    success: function success(res) {
                        console.log(res);
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    clearSet: function clearSet() {
        swan.removeStorage({
            key: 'userMobile',
            success: function success(res) {
                console.log("清除本地缓存的手机号" + res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }
});});

/***/ }),
/* 73 */
/***/ (function(module, exports) {

PageDefine('pages/carAccess/carAccess', function (Page, getApp) {"use strict";

Page({
    date: '',
    data: {
        currentTab: 1,
        host: "https://baidu.xin.com",
        data: { //data为空表示失败
            class: "active",
            "price": { //价格模块
                "A": "4.18", //车况优秀，精确估价值（万元）
                "B": "4.09", //车况良好，精确估价值（万元）
                "C": "3.98", //车况一般，精确估价值（万元）
                "D": "3.67" //车况较差，精确估价值（万元）
            },
            "hangqing": { //行情模块
                "current_year": '2017', //当前年份
                "current_price": "27.07", //当前价格
                "one_year_after": 20.13, //一年后价格（万元）
                "two_year_after": 16.13, //二年后价格（万元）
                "three_year_after": 10.13 //三年后价格（万元）
            },
            "serieimg": "http://c2.xinstatic.com/che/20161213/1737/584fc144e7fb5846787_22.jpg", //车图
            "evaluate_url": "http://m.ceshi.xin.com/evaluate_car/show_price/ckdbsmtrn10.html", //估价分享地址
            "recent_cj_record": [//近期成交记录模块
            {
                "carimg": "http://c2.xinstatic.com/f2/20171102/1404/59fab5593f689312553_18.jpg", //车图
                "cityname": "北京", //城市
                "nickname": "测先生", //出售人
                "deal_time": "近期售出", //成交时间
                "carname": "福田 萨普 2015款 2.4 手动 豪华版5555长后驱4G69S4N", //车辆名称
                "registe_date": "2017", //上牌日期
                "mileage": "5.00" //表现里程
            }, {
                "carimg": "http://c1.xinstatic.com/f2/20171102/1349/59fab1d5c7016753120_18.jpg",
                "cityname": "北京",
                "nickname": "测先生",
                "deal_time": "近期售出",
                "carname": "昌河 福瑞达K22 2017款 1.5 手动 经济型DK15",
                "registe_date": "2017",
                "mileage": "5.00"
            }],
            "user_input": {
                "brandid": 62, //品牌ID
                "seriesid": 269, //车系ID
                "modeid": 90002197, //车型ID
                "cityid": 201, //出售城市ID
                "mileage": 6, //行驶里程（万公里）
                "registe_cityid": 2401, //上牌城市ID
                "regist_date": "2016-06", //上牌时间
                "car_age": 1.4, //车龄（年）
                "carname": "奥迪 A6L 2016款 1.8T 自动 TFSI技术型", //车辆名称
                "serieimg": "http://c5.xinstatic.com/che/20161209/1442/584a523978203960307_22.jpg", //车图
                "retail_price": "27.08", //估价价格
                "registe_cityname": "上海", //上牌城市名称
                "is_c2b_city": 1, //出售城市是否为c2b城市
                "evaluate_lead_id": 748 //估价线索ID
            }
        }
    },
    onLoad: function onLoad(option) {
        swan.setNavigationBarTitle({
            title: '车辆估价',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
        //    估价成功的页面不再需要去发送请求，数据是从上一个页面以参数的形式传过来的
        var data = option.data;
        var date = option.data.hangqing.current_year * 1;
        this.setData({
            data: data,
            date: date
        });
    },
    toOrderCar: function toOrderCar() {
        swan.makePhoneCall({
            phoneNumber: '4006131628',
            success: function success(res) {
                console.log("拨打电话成功" + res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    },
    bindChange: function bindChange(e) {
        this.setData({ currentTab: e.detail.current });
    },
    switchTab: function switchTab(e) {
        if (e.target.dataset.current === this.data.currentTab) {
            return false;
        } else {
            this.setData({ currentTab: e.target.dataset.current });
        }
    }
});});

/***/ }),
/* 74 */
/***/ (function(module, exports) {

PageDefine('pages/onePercent/onePercent', function (Page, getApp) {'use strict';

Page({
    onLoad: function onLoad() {
        swan.setNavigationBarTitle({
            title: '一成购',
            success: function success(res) {
                console.log(res);
            },
            fail: function fail(res) {
                console.log(res);
            }
        });
    }
});});

/***/ }),
/* 75 */
/***/ (function(module, exports) {

PageDefine('pages/removeStorageMine/removeStorageMine', function (Page, getApp) {'use strict';

Page({
    oneItemClick: function oneItemClick() {
        swan.removeStorage({
            key: 'userMobile',
            success: function success(res) {
                swan.showToast({
                    title: '删除返回结果:::' + JSON.stringify(res)
                });
            },
            fail: function fail(err) {
                console.log('fail:::' + JSON.stringify(err));
            }
        });
    }
});});

/***/ })
/******/ ]);