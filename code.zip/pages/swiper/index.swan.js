"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <text>\u6C34\u5E73\u6EDA\u52A8\uFF0C\u81EA\u52A8\u64AD\u653E</text>\n<text>\u7EB5\u5411\u6EDA\u52A8</text>\n<swiper indicator-active-color=\"red\" interval=\"5000\" autoplay=\"true\" indicator-dots current=\"3\" on-bindchange=\"eventHappen('change', $event, 'swiperChange', '')\">\n    <swiper-item>\n        <img src=\"http://a.hiphotos.baidu.com/image/h%3D300/sign=3198b5aa46c2d562ed08d6edd71390f3/7e3e6709c93d70cfb367b1c7f1dcd100bba12b5e.jpg\" class=\"single-img\"/>\n    </swiper-item>\n    <swiper-item>\n        <img src=\"http://g.hiphotos.baidu.com/image/h%3D300/sign=055929f853afa40f23c6c8dd9b66038c/562c11dfa9ec8a13158ec92afe03918fa1ecc060.jpg\" class=\"single-img\"/>\n    </swiper-item>\n    <swiper-item s-for=\"link in items\">\n        <image src=\"{{link}}\" class=\"single-img\"></image>\n    </swiper-item>\n</swiper>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);