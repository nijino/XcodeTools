"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"wrap\">\n    <view class=\"orderSellerWrap\">\n        <view class=\"banner\">\n            <image src=\"http://s4.xinstatic.com/m/img/smallprogram/sellerBanner@2x.png\" class=\"bannerImg\"></image>\n        </view>\n        <view class=\"infoWrap\">\n            <view class=\"infoList\">\n                <view class=\"info\">\u51FA\u552E\u57CE\u5E02</view>\n                <text class=\"infoContent\"  on-bindtap=\"eventHappen('tap', $event, 'chooseSellCity', '')\" >{{sellCity.cityname?sellCity.cityname:city.cityname}}</text>\n            </view>\n            <view class=\"infoList\">\n                <view class=\"info\">\u4E0A\u724C\u57CE\u5E02</view>\n                <text class=\"infoContent\" on-bindtap=\"eventHappen('tap', $event, 'choosePlateCity', '')\" >{{plateCity.cityname?plateCity.cityname:city.cityname}}</text>\n            </view>\n            <view class=\"infoList\">\n                <view class=\"info\">\u54C1\u724C\u8F66\u7CFB</view>\n                <text class=\"infoContent\" on-bindtap=\"eventHappen('tap', $event, 'chooseCarClick', '')\">{{chooseBrand.carDetailName?chooseBrand.carDetailName:'\u8BF7\u9009\u62E9\u8F66\u724C&\u8F66\u578B'}}</text>\n            </view>\n            <view class=\"infoList\">\n                <view class=\"info\">\u884C\u4F7F\u91CC\u7A0B</view>\n                <input type=\"text\" value=\"{{data}}\" class=\"pleaseImport\"  placeholder=\"\u8BF7\u8F93\u5165\u91CC\u7A0B\u6570\" autocomplete=\"off\" maxlength=\"4\"  on-bindinput=\"eventHappen('input', $event, 'getValue', '')\"/>\n                <text class=\"mileage\">\u4E07\u516C\u91CC</text>\n            </view>\n            <view class=\"infoList\">\n                <view class=\"info\">\u4E0A\u724C\u65F6\u95F4</view>\n                <picker mode=\"date\" value=\"{{date}}\"  fields=\"day\" on-bindchange=\"eventHappen('change', $event, 'bindDateChange', '')\">\n                    <view  class=\"infoContent\" >{{date==''?'\u8BF7\u9009\u62E9\u4E0A\u724C\u65F6\u95F4':date}}</view>\n                </picker>\n            </view>\n        </view>\n        <view on-bindtap=\"eventHappen('tap', $event, 'clearSet', '')\">\u6E05\u9664\u4FDD\u5B58\u7684\u624B\u673A\u53F7</view>\n        <view class=\"submitWrap\"   on-bindtap=\"eventHappen('tap', $event, 'isShowClick', '')\">\n            <view class=\"submit\">\n                {{btnText}}\n            </view>\n        </view>\n    </view>\n    <view class=\"msgWrap\" s-if=\"isShow\">\n        <view class=\"mask\"></view>\n        <view class=\"msgTop\">\n            <view class=\"msgTitle\">\u77ED\u4FE1\u9A8C\u8BC1</view>\n            <view class=\"msgPoint\">\u77ED\u4FE1\u9A8C\u8BC1\u624B\u673A\u53F7\u7801\u540E\u624D\u80FD\u63D0\u4EA4\u9884\u7EA6\u4FE1\u606F</view>\n            <view class=\"inputWrap\">\n                <view class=\"inputBox\">\n                    <input placeholder=\"\u8BF7\u8F93\u5165\u624B\u673A\u53F7\" class=\"inputContent input\" autocomplete=\"off\" maxlength=\"11\" on-bindinput=\"eventHappen('input', $event, 'getMobileNum', '')\" on-bindblur=\"eventHappen('blur', $event, 'getMobile', '')\"/>\n                </view>\n            </view>\n            <view class=\"inputWrap\">\n                <view class=\"inputBox\">\n                    <input  placeholder=\"\u8BF7\u8F93\u5165\u9A8C\u8BC1\u7801\"  class=\"input\" autocomplete=\"off\" maxlength=\"6\" on-bindinput=\"eventHappen('input', $event, 'getCodeNum', '')\"/>\n                    <text class=\"border\"></text>\n                    <text class=\"gainCode\" on-bindtap=\"eventHappen('tap', $event, 'getCode', '')\">{{text}}</text>\n                </view>\n            </view>\n            <view>{{Data}}</view>\n            <view class=\"btnWrap\">\n                <view class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'submitClick', '')\">\u9884\u7EA6\u5356\u8F66</view>\n            </view>\n        </view>\n    </view>\n</view>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);