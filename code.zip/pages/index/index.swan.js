"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        \n<button on-bindtap=\"eventHappen('tap', $event, 'loadMore', '')\">\n    \u70B9\u51FB\u52A0\u8F7D\u66F4\u591A\n</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'openHome', '')\">\n  \u8DF3\u8F6C-\u9996\u9875\n</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'openFanice', '')\">\n    \u91D1\u878D\u65B9\u6848\u9875\n</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'openParams', '')\">\n    \u53C2\u6570\u914D\u7F6E\u9875\n</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'openFreeCall', '')\">\n    \u514D\u8D39\u901A\u8BDD\u9875\n</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'redirectToCarlist', '')\">\n    \u8FDB\u5165\u5217\u8868\u9875\n</button>\n<button on-bindtap=\"eventHappen('tap', $event, 'redirectToBrandlist', '')\">\n  \u54C1\u724C\u9009\u62E9\n</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'directClick', '')\">\u5168\u56FD\u76F4\u8D2D</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'identifyClick', '')\">\u4F18\u4FE1\u8BA4\u8BC1</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'sellerCarClick', '')\">\u6211\u8981\u5356\u8F66</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'orderClick', '')\">\u9884\u7EA6\u6210\u529F</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'orderSeller', '')\">\u9884\u7EA6\u5356\u8F66</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'carAccess', '')\">\u8F66\u8F86\u4F30\u4EF7</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'onePercent', '')\">\u4E00\u6210\u8D2D</button>\n<button class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'storageDel', '')\">\u5220\u9664\u6570\u636E</button>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);