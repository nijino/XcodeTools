"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"banner\">\n\n</view>\n<view class=\"carInfo\">\n    <text class=\"carname\">\n        {{financialplan.car_detail.name}}\n    </text>\n    <text class=\"fullPrice\">\n        \u5168\u4EF7:&ensp;{{financialplan.car_detail.full_price}}\u4E07\u5143\n    </text>\n</view>\n<view class=\"cases\">\n    \u60A8\u53EF\u4EE5\u81EA\u7531\u9009\u62E9\u9996\u4ED8\u91D1\u878D\u65B9\u6848\n</view>\n<view class=\"tab\">\n    <text class=\"tabItem {{item.a[0].title==isShow ? 'current' : ''}}\" s-for=\"item in TotalRes\" data-colorNum=\"{{item.a[0].title}}\" on-bindtap=\"eventHappen('tap', $event, 'changeColor', '')\">\u9996\u4ED8{{item.a[0].title}}\u6210</text>\n</view>\n\n<view class=\"panelContent {{item.a[0].title==isShow ? 'contentShow' : ''}}\" s-for=\"item in TotalRes\">\n    <text class=\"firstPay\">\u9996\u4ED8\u6B3E<text class=\"dPrice\">{{item.a[0].down_payment}}</text>\u4E07</text>\n    <view  s-for=\"details,index in item.a\">\n        <view class=\"solutionItem\">\n            <text class=\"solutions\">\u65B9\u6848{{index+1}}</text>\n            <text class=\"solutions\">\u6708\u4F9B{{ details.monthly_payment    }}\u5143</text>\n            <text class=\"solutions\">{{details.loan_term}}\u671F</text>\n        </view>\n        <text class=\"feeTip\">{{details.loan_term}}\u671F\u5DF2\u5305\u542B\u8D39\u7528{{details.profit_all}}\u5143\uFF0C\u5E74\u8D39\u7387{{details.annual_rate}}%</text>\n        <view class=\"solutionLine\"></view>\n    </view>\n\n</view>\n\n<view class=\"tips\">\n    <text>GPS\u7B49\u8D39\u7528\u6839\u636E\u5B9E\u9645\u60C5\u51B5\u53E6\u5916\u6536\u53D6</text>\n    <text>\u9996\u4ED8\u4EE5\u60A8\u901A\u8FC7\u4FE1\u5BA1\u540E\u7684\u5B9E\u9645\u4EF7\u683C\u4E3A\u51C6,\u9996\u4ED8\u6BD4\u4F8B\u4EE5\u5B9E\u9645\u91D1\u878D\u65B9\u6848\u4E3A\u51C6</text>\n</view>\n\n<view class=\"applyProcess\">\n    <view class=\"applyTop\">\n        <text class=\"applyLine\"></text>\n        <text class=\"applyTitle\">\u7533\u8BF7\u6D41\u7A0B</text>\n        <text class=\"applyLine\"></text>\n    </view>\n\n    <view class=\"applyBottom\">\n        <view class=\"applyLeft\">\n            <text class=\"circular\"></text>\n            <text class=\"border\"></text>\n            <text class=\"circular\"></text>\n            <text class=\"border\"></text>\n            <text class=\"circular\"></text>\n        </view>\n\n        <view class=\"applyRight\">\n            <text class=\"applyTip\">\u63D0\u4EA4\u7533\u8BF7</text>\n            <text class=\"applyTxt\">\u7EBF\u4E0A\u63D0\u4EA4\u57FA\u7840\u4FE1\u606F\u540E\uFF0C\u4F18\u4FE1\u4F1A\u7B2C\u4E00\u65F6\u95F4\u4E3A\u60A8\u5B89\u6392\u4E13\u5C5E\u8D2D\u8F66\u987E\u95EE\u63D0\u4F9B1\u5BF91\u670D\u52A1</text>\n            <text class=\"applyTip\">\u6781\u901F\u5BA1\u6279 </text>\n            <text class=\"applyTxt\">\u7EBF\u4E0B\u9884\u7EA6\u770B\u8F66\uFF0C\u5728\u8D2D\u8F66\u987E\u95EE\u534F\u52A9\u4E0B\u63D0\u4EA4\u8EAB\u4EFD\u8BC1\u3001\u9A7E\u9A76\u8BC1\u3001\u501F\u8BB0\u5361\u4FE1\u606F\uFF0C\u6700\u5FEB60\u5206\u949F\u5373\u53EF\u67E5\u770B\u5BA1\u6279\u7ED3\u679C</text>\n            <text class=\"applyTip\">\u4E00\u7AD9\u63D0\u8F66</text>\n            <text class=\"applyTxt\">\u786E\u5B9A\u6210\u4EA4\u610F\u5411\u540E\uFF0C\u4F18\u4FE1\u4E3A\u60A8\u63D0\u4F9B\u5305\u62EC\u5408\u540C\u7B7E\u7F72\u3001\u8F66\u8F86\u8FC7\u6237\u3001\u62B5\u62BC\u529E\u7406\u5728\u5185\u7684\u4E00\u7AD9\u5F0F\u670D\u52A1</text>\n        </view>\n    </view>\n</view>\n\n<view class=\"call\" on-bindtap=\"eventHappen('tap', $event, 'call400', '')\">\u7535\u8BDD\u54A8\u8BE2</view>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);