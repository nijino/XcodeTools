"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"call\">\n    <text class=\"title\">\u514D\u8D39\u901A\u8BDD</text>\n    <text class=\"infos\">\n        \u8BF7\u60A8\u8F93\u5165\u60A8\u7684\u7535\u8BDD\u53F7\uFF0C\u4FBF\u53EF\u4E0E\u5546\u5BB6\u514D\u8D39\u901A\u8BDD\u3002\u60A8\u5C06\u6536\u5230\u6765\u7535\uFF0C\u8BF7\u6CE8\u610F\u63A5\u542C\u3002\n\n    </text>\n    <view class=\"writeTel\">\n        <input type=\"text\" class=\"phoneText\" placeholder=\"\u8BF7\u8F93\u5165\u60A8\u7684\u624B\u673A\u53F7\" value=\"{{telephoneNum}}\"/>\n        <text class=\"close\" on-bindtap=\"eventHappen('tap', $event, 'cancelValue', '')\"></text>\n    </view>\n    <view class=\"callFree\">\u514D\u8D39\u901A\u8BDD</view>\n</view>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);