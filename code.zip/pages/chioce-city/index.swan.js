"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"normalBg curCityRemark\" s-if=\"onlyList\">\n<text class=\"txt\">\u5F53\u524D\u5B9A\u4F4D\u57CE\u5E02</text>\n</view>\n<view class=\"curCityName\" s-if=\"onlyList\"><text class=\"txt\">{{currentCity.cityname}}</text></view>\n<view class=\"normalBg hotArea\" s-if=\"onlyList\"><text class=\"txt\">\u70ED\u95E8\u57CE\u5E02</text></view>\n<view class=\"hotAreaList\" s-if=\"onlyList\">\n  <text on-bindtap=\"eventHappen('tap', $event, 'onChooseCityClick', '')\"  s-for=\"item,index in hotAreaList\" data-sell=\"{{item.is_sell_car}}\" data-index=\"{{index}}\" data-cityid=\"{{item.cityid}}\" data-cityname=\"{{item.cityname}}\"\n   class=\"item {{(isSellCity == 'yes' && item.is_sell_car == 0)?'on':''}}\">{{item.cityname}}</text>\n</view>\n<view s-for=\"letter in preLetterList\">\n  <view class=\"normalBg indexLetter\"><text class=\"txt\">{{letter}}</text></view>\n  <view class=\"indexList\">\n    <text on-bindtap=\"eventHappen('tap', $event, 'onChooseCityClick', '')\"  s-for=\"item,index in cities[letter]\" data-sell=\"{{item.is_sell_car}}\" data-index=\"{{index}}\" data-letter=\"{{letter}}\" data-cityid=\"{{item.cityid}}\" data-cityname=\"{{item.cityname}}\"\n    class=\"item {{(isSellCity == 'yes' && item.is_sell_car == 0)?'on':''}}\" s-if=\"!(isSellCity == 'yes' && item.is_sell_car == 0)\">{{item.cityname}}</text>\n  </view>\n</view>\n<view class=\"bottom\" s-if=\"cities.A\">\n    <view class=\"bottomText\">\u66F4\u591A\u57CE\u5E02\u5F00\u901A\u4E2D...</view>\n</view>\n<view class=\"right\">\n    <view class=\"rightIndex\">\n     <text class=\"hot\">\u70ED</text>\n     <text class=\"start\">\u2605</text>\n       <view class=\"list\">\n          <text s-for=\"item in preLetterList\" class=\"item\">{{item}}</text>\n       </view>\n    </view>\n</view>\n\n\n\n\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);