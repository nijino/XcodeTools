"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"section\">\n  <view class=\"item\">\n      \u7AD6\u5411\u6EDA\u52A8\uFF0C\u671F\u671B\u6548\u679C\uFF1A1. \u521D\u59CB\u5316\u4F4D\u7F6E\u6EDA\u52A8\u6761\u4E0D\u5728\u9876\u90E8; 2. \u6ED1\u5230\u9876\u90E8\u5E95\u90E8\u65F6\u89E6\u53D1\u5230\u9876\u4E8B\u4EF6\uFF0C\u5F39\u51FAtoast;3. \u6EDA\u52A8\u8FC7\u7A0B\u5F39\u51FAtoast,log\u8F93\u51FAe.detail;\n  </view>\n      \n  <scroll-view scroll-y style=\"height: 300px;\" \n      on-bindscrolltoupper=\"eventHappen('scrolltoupper', $event, 'upper', '')\" on-bindscrolltolower=\"eventHappen('scrolltolower', $event, 'lower', '')\" scroll-into-view=\"four\"\n      upper-threshold=\"10\"  lower-threshold=\"10\" scroll-top=\"150\" scroll-with-animation=\"true\" on-bindscroll=\"eventHappen('scroll', $event, 'myscroll', '')\"\n      enable-back-to-top=\"true\">\n      <view id=\"one\" class=\"bg-red\">view1</view>\n      <view id=\"two\" class=\"bg-green\">view2</view>\n      <view id=\"three\" class=\"bg-yellow\">view3</view>\n      <view id=\"four\" class=\"bg-blue\">view4</view>\n  </scroll-view>\n<view>\n  <view class=\"item\">\n      \u6A2A\u5411\u6EDA\u52A8\uFF0C\u671F\u671B\u6548\u679C\uFF1A1. \u521D\u59CB\u5316\u6A2A\u5411\u6EDA\u52A8\u6761\u4F4D\u7F6E\u4E0D\u5728\u8FB9\u7F18; 2. \u6ED1\u5230\u5DE6\u8FB9\u53F3\u8FB9\u65F6\u89E6\u53D1\u5230\u9876\u4E8B\u4EF6\uFF0C\u5F39\u51FAtoast\n  </view>\n\n  <scroll-view scroll-y scroll-x style=\"height: 300px; width: 400px\"  on-bindscrolltoupper=\"eventHappen('scrolltoupper', $event, 'upper', '')\" on-bindscrolltolower=\"eventHappen('scrolltolower', $event, 'lower', '')\"scroll-into-view=\"five\" upper-threshold=\"1\"  lower-threshold=\"1\" scroll-top=\"100\" on-bindscroll=\"eventHappen('scroll', $event, 'scroll', '')\">\n      <view id=\"six\" class=\"bg-green herizon-view\">view2</view>\n      <view id=\"seven\" class=\"bg-yellow herizon-view\">view3</view>\n      <view id=\"eight\" class=\"bg-blue herizon-view\">view4</view> \n  </scroll-view>\n</view>\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);