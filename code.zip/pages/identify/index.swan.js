"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"wrap\">\n    <view class=\"oneImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-1-v-2@2x.png\" class=\"oneImg\"/>\n    </view>\n    <view class=\"twoImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-3-v-1@2x.png\" class=\"twoImg\"/>\n    </view>\n    <view class=\"threeImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-4@2x.png\" class=\"threeImg\"/>\n    </view>\n    <view class=\"fourImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-9@2x.png\" class=\"fourImg\"/>\n    </view>\n     <view class=\"fiveImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-10@2x.png\" class=\"fiveImg\"/>\n    </view>\n    <view class=\"sixImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-7@2x.png\" class=\"sixImg\"/>\n    </view>\n    <view class=\"sevenImgWrap\">\n        <img src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-8-v-1@2x.png\" class=\"sevenImg\"/>\n    </view>\n    <view class=\"goodCarWrap\">\n        <view class=\"goodCar\" on-bindtap=\"eventHappen('tap', $event, 'goShopClick', '')\">\n            \u9A6C\u4E0A\u53BB\u8BA4\u8BC1\u597D\u8F66\n        </view>\n    </view>\n</view>\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);