"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"SearchBox\">\n    <view class=\"SearchContent\">\n        <image src=\"https://cdn.zeplin.io/5a31ef9e4a95f47088b572c1/assets/5B65894E-6066-4FDC-B8F5-9398E84E4E6C.png\" class=\"searchicon\"></image>\n        <input class=\"placeholder\" placeholder=\"\u641C\u7D22\u60A8\u60F3\u8981\u7684\u8F66\" on-bindinput=\"eventHappen('input', $event, 'changeValue', '')\"/>\n    </view>\n\n    <text class=\"Exit\" on-bindtap=\"eventHappen('tap', $event, 'onHome', '')\">\u53D6\u6D88</text>\n</view>\n<view s-if=\"{{isShow == 1 ? true : false}}\">\n\n    <view class=\"history search\">\n        <view class=\"historyTitle searchTip\">\n            <text>\u5386\u53F2\u641C\u7D22</text>\n            <text class=\"remove\" on-bindtap=\"eventHappen('tap', $event, 'cleanTip', '')\">\u5220\u9664</text>\n        </view>\n        <view class=\"historyContent searchDetails\">\n            <text s-for=\"itemOne in History\" data-query=\"{{itemOne.query}}\" data-keyword=\"{{itemOne.carname}}\" on-bindtap=\"eventHappen('tap', $event, 'GoCarList', '')\">{{itemOne.carname}}</text>\n        </view>\n    </view>\n\n    <view class=\"hot search\">\n        <view class=\"hotTitle searchTip\">\n            <text>\u70ED\u95E8\u641C\u7D22</text>\n        </view>\n        <view class=\"hotContent searchDetails\">\n            <text s-for=\"itemTwo in Hot\" data-searchParam=\"{{itemTwo.param}}\" on-bindtap=\"eventHappen('tap', $event, 'toSearchHot', '')\">{{itemTwo.car}}</text>\n        </view>\n    </view>\n</view>\n\n\n<view class=\"suggest\" s-if=\"{{isShow == 2 ? true : false}}\">\n    <text class=\"sug_text\" s-for=\"item in suggestMsg\" data-query=\"{{item.query}}\" data-keyword=\"{{item.keyword}}\" on-bindtap=\"eventHappen('tap', $event, 'GoCarList', '')\">{{item.keyword}}</text>\n</view>\n\n\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);