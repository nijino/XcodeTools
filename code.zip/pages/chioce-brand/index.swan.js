"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
  _inherits(Index, _SwanBase);

  function Index(options) {
    _classCallCheck(this, Index);

    return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
  }

  return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view on-bindtouchmove=\"eventHappen('touchmove', $event, 'closeChioce', '')\">\n    <view s-if=\"isNoLimitShow\">\n        <view class=\"normalBg\">\n          <text class=\"txt\">\u70ED\u95E8\u54C1\u724C</text>\n        </view>\n        <!--\u70ED\u95E8\u54C1\u724C\u5217\u8868-->\n        <view class=\"hotBrandList\">\n            <view s-for=\"item in hotBrandList\" class=\"item\" data-brandId=\"{{item.brandid}}\" data-brandName=\"{{item.brandname}}\" on-bindtap=\"eventHappen('tap', $event, 'ChangeShow', '')\">\n              <img src=\"{{item.brandimg}}\" class=\"brandImg\"/>\n              <text class=\"brandName\">{{item.brandname}}</text>\n            </view>\n        </view>\n\n        <view class=\"normalBg\">\n          <text class=\"txt allBrandLetter\">\u2605</text>\n        </view>\n        <view class=\"allBrand\" data-brandId=\"0\" on-bindtap=\"eventHappen('tap', $event, 'NoLimit', '')\"><text class=\"txt\">\u4E0D\u9650\u54C1\u724C</text></view>\n\n    </view>\n\n    <view  s-for=\"letter in preLetterList\" class=\"brandList\">\n      <view class=\"normalBg\">\n        <text class=\"txt\">{{letter}}</text>\n      </view>\n      <view  on-bindtap=\"eventHappen('tap', $event, 'ChangeShow', '')\" data-brandId=\"{{item.brandid}}\" data-brandName=\"{{item.brandname}}\" s-for=\"item in brandList[letter]\" class=\"item\">\n        <img class=\"itemImg\" src=\"{{item.brandimg}}\"/>\n        <text class=\"itemName\">{{item.brandname}}</text>\n      </view>\n    </view>\n\n\n    <view class=\"rightIndex\">\n    <view s-if=\"isNoLimitShow\">\n        <text class=\"hot\">\u70ED</text>\n        <text class=\"start\">\u2605</text>\n    </view>\n\n       <view class=\"list\">\n          <text s-for=\"item in preLetterList\" class=\"item\" on-bindtap=\"eventHappen('tap', $event, 'showToast', '')\" data-text=\"{{item}}\">{{item}}</text>\n       </view>\n    </view>\n</view>\n\n\n<!--\u8F66\u7CFB\u5217\u8868-->\n<view class=\"seriesBox {{moveNum==1 ?'movedBox':'beforeMoveBox'}} \" s-if=\"isCarShow\">\n  <scroll-view class=\"carTypeScrollView\" scroll-y=\"true\">\n      <view class=\"brandInfo\" >\n          <img src=\"{{currentSeriesList.brandimg}}\"/>\n          <text class=\"name\">{{currentSeriesList.brandname}}</text>\n      </view>\n      <view s-for=\"series in currentSeriesList.serie\" class=\"seriesList\">\n        <view class=\"normalBg\">\n          <text class=\"txt\">{{series.makename}}</text>\n        </view>\n        <view class=\"item\" on-bindtap=\"eventHappen('tap', $event, 'onCarType', '')\" s-for=\"detail in series.serielist\" data-model=\"{{detail.model}}\" data-serieName=\"{{detail.seriename}}\" data-serieId=\"{{detail.serieid}}\">\n          <view class=\"picContent\" s-if=\"{isPicShow}}\">\n            <img class=\"itemImg\" src=\"{{detail.head_pic}}\" />\n          </view>\n          <text class=\"itemName\">{{detail.seriename}}</text>\n          <text class=\"itemCount\"></text>\n        </view>\n      </view>\n    </scroll-view>\n</view>\n\n\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);