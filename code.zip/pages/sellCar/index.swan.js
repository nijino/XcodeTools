"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave running js
 * @author houyu(houyu01@baidu.com)
 */
var SwanBase = window.SwanBase;

var Index = function (_SwanBase) {
    _inherits(Index, _SwanBase);

    function Index(options) {
        _classCallCheck(this, Index);

        return _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));
    }

    return Index;
}(SwanBase);

Index.template = "<swan-wrapper>\n        <view class=\"sellerWrap\">\n    <view class=\"bannerWrap\">\n        <image src=\"http://s4.xinstatic.com/m/img/smallprogram/uxin-pic-1-v-2@2x.png\" class=\"bannerImage\"></image>\n    </view>\n    <view class=\"num\">\n        <text class=\"numTxt\">\n            {{num}}\n        </text>\n        \u8F86\u8F66\u6210\u529F\u5728\u4F18\u4FE1\u552E\u51FA\n    </view>\n    <view class=\"btnWrap\">\n        <view class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'orderSellerCar', '')\">\u9884\u7EA6\u5356\u8F66</view>\n    </view>\n    <view class=\"btnTwo\">\n        <view class=\"btnLeft\" on-bindtap=\"eventHappen('tap', $event, 'freeConsultClick', '')\">\u514D\u8D39\u54A8\u8BE2</view>\n        <view class=\"btnRight\" on-bindtap=\"eventHappen('tap', $event, 'accessPrice', '')\">\u5148\u4F30\u4E2A\u4EF7</view>\n    </view>\n    <view class=\"title\">\u4EF7\u683C\u9AD8</view>\n    <view class=\"imageWrap\">\n        <image class=\"pic pic1\" src=\"http://s5.xinstatic.com/m/img/c2b-index-1.png?v=17120712\">\n        </image>\n    </view>\n    <view class=\"prepareWrap\">\n        <view class=\"prepare\">\u4E00\u6B21\u62A5\u4EF77\u5929\u6709\u6548\uFF0C\u597D\u4EF7\u683C\u7ECF\u5F97\u8D77\u6BD4\u8F83</view>\n    </view>\n    <view class=\"title\">\n        \u6210\u4EA4\u5FEB\n    </view>\n    <view class=\"imageWrap\">\n        <image class=\"pic pic2\" src=\"http://s5.xinstatic.com/m/img/c2b-index-2.png?v=17120712\">\n        </image>\n        <image class=\"picture\" src=\"http://s5.xinstatic.com/m/img/c2b-index-bg2.jpg?v=17120712\">\n        </image>\n    </view>\n    <view class=\"title\">\n        \u5B89\u5168\u53EF\u9760\n    </view>\n    <view class=\"imageWrap\">\n        <image class=\"pic pic3\" src=\"http://s5.xinstatic.com/m/img/c2b-index-3.png?v=17120712\">\n        </image>\n        <image class=\"picture\" src=\"http://s5.xinstatic.com/m/img/c2b-index-bg3.jpg?v=17120712\">\n        </image>\n    </view>\n    <view class=\"btnWrap\">\n            <view class=\"btn\" on-bindtap=\"eventHappen('tap', $event, 'orderSellerCar', '')\">\u9884\u7EA6\u5356\u8F66</view>\n    </view>\n</view>\n    </swan-wrapper>";


var index = new Index();
index.attach(document.body);